# CS367 P3 Implementation Approach

## Implementation Priorities

1. **Read and understand project documentation thoroughly**
2. **Focus on implementing the required functionality in `p3_handout/src/hiy.c`**
3. **Test the implementation thoroughly**
4. **Ensure all functions work correctly and match the required specifications**

