# CS367 P3 Project Implementation Guidelines

## Project Requirements

The following are the key requirements for implementing the CS367 P3 project:

1. **Strict File Editing**:
   * ONLY edit `p3_handout/src/hiy.c`
   * All other project files are READ-ONLY

2. **Implementation Focus**:
   * Implement all required functionality as specified in the project documentation
   * Follow the exact function signatures defined in header files
   * Implement all required error handling as specified in documentation

3. **Testing and Verification**:
   * Compile the project with `make` within the `p3_handout/` directory
   * Test the implementation by running the compiled `./hiy` shell
   * Verify correctness against project requirements 