# CS367 P3 Project Scope

## Project Overview

This document defines the core requirements and scope for the CS367 P3 project implementation.

## Key Requirements

1. **File Editing Scope**:
   * Only modify `p3_handout/src/hiy.c`
   * No other files should be changed

2. **Implementation Standards**:
   * Implement the required functionality per project documentation
   * Focus on correct, clean, and efficient code
   * No comments in the implementation

3. **Testing**:
   * Test the implementation thoroughly
   * Use compilation and runtime testing to verify correctness 