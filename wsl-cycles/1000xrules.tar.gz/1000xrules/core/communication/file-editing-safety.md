# File Editing Safety Guidelines

## CS367 P3 Project-Specific Restrictions

### ⚠️ ABSOLUTE REQUIREMENTS ⚠️

1. **ONLY Edit `p3_handout/src/hiy.c`**:
   * NO OTHER project file may be modified
   * This restriction supersedes any general implementation guidelines
   * There are NO EXCEPTIONS to this rule

2. **NO Comments Allowed During Implementation**:
   * DO NOT add comments to `hiy.c` during implementation
   * Comments will be handled in a separate dedicated cycle
   * Implementation must focus solely on functional code

3. **NO New Files**:
   * DO NOT create new files for the CS367 P3 project
   * Work exclusively with existing files
   * Ensure all implementation stays within `hiy.c`

4. **Thorough Documentation Review**:
   * ALWAYS review ALL documentation in `p3_strict_instructions/documentation-pages-md/` during planning and implementation
   * Ensure implementation follows the requirements and constraints in project documentation

5. **Fully Autonomous Development**:
   * 1000xdev is FULLY AUTHORIZED and REQUIRED to run all necessary terminal commands
   * Execute `make` to compile the project and `./hiy` for testing
   * Implement full autonomous build and test processes
   * No human intervention should be needed for any development, build, or test activities

These project-specific requirements are NON-NEGOTIABLE and take precedence over any other implementation guidance.
