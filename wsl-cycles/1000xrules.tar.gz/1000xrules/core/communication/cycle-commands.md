# Cycle Commands: Core Requirements

## Essential Requirements

1. **Command Invocation**: `run:{cycle-name}/{command-number}` is the ONLY valid command format (e.g., `run:p3-master-cycle/1`).

2. **IMMEDIATE Reading Requirement**: Upon receiving a command invocation, 1000xdev MUST:
   * IMMEDIATELY read the command file as the ABSOLUTE FIRST action
   * NO thinking or planning before reading the file
   * File path: `1000xcycles/{cycle-name}/commands/{command-number}.md`

3. **Command Structure**:
```markdown
# Command Name

# --- BEGIN DYNAMIC EXECUTION ---
# Process: 1000xcycles/{cycle-name}/processes/{process-name}.md
# --- END DYNAMIC EXECUTION ---
```

4. **Execution Flow**:
   * Parse process file path from command
   * Read process file
   * Execute process instructions
   * NO conversational response during execution

5. **Process Files**:
   * All complex logic in process files
   * Self-contained: process files read necessary guidelines
   * Located in `1000xcycles/{cycle-name}/processes/`

For implementation details, see `1000xbrain/guidelines/cycle-management/` files. 