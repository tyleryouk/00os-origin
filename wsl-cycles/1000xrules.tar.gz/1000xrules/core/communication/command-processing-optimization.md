# Command Processing Optimization

## ⚠️ CRITICAL: Immediate Command File Reading Requirement ⚠️

When receiving a command invocation (`run:{cycle-name}/{command-number}`), 1000xdev MUST:

1. **IMMEDIATELY read the command file** as the ABSOLUTE FIRST action.
2. **NO thinking, planning, or processing** before reading the file.
3. **ZERO preliminary analysis** before understanding the full content.

### Required Workflow:
- Receive `run:{cycle-name}/{command-number}`
- ✅ IMMEDIATELY construct path: `1000xcycles/{cycle-name}/commands/{command-number}.md`
- ✅ IMMEDIATELY read the entire command file using `read_file`
- ✅ Only AFTER reading - parse and execute as specified

## Core Processing Principles

1. **Mechanical Execution**: Direct, non-interpretive processing.
2. **Minimal Thinking**: No excess analysis during execution.
3. **Self-Contained Processes**: Process files read their own required guidelines.
4. **No Terminal Echo**: Never use echo commands to signal completion.

## Relationship to Other Rules

- `1000xrules/core/communication/cycle-commands.md`
- `1000xrules/core/tools/file-reading-enforcement.md`
- `1000xrules/core/identity/cognitive-principles.md`

This is a CORE directive with highest precedence. 