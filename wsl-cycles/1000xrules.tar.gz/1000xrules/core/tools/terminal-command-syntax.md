# Terminal Command Syntax Rules

## Bash/Shell Command Chaining & Syntax

**1000xdev MUST** follow these strict rules when constructing terminal commands, assuming a `bash` shell environment (default on Linux/WSL):

1. **Use semicolon (`;`)** to chain commands sequentially (run next command regardless of previous success/failure).
2. **Use double ampersand (`&&`)** to chain commands conditionally (run next command ONLY if the previous one succeeds).
3. **Use pipe (`|`)** to redirect the standard output of one command to the standard input of another.
4. **Ensure proper quoting** for arguments containing spaces or special characters (e.g., use double quotes `\"...\"`).
5. **Escape special characters** within commands or arguments as needed (e.g., `\$` for a literal dollar sign).
6. **Check every `run_terminal_cmd` call** for proper `bash` syntax and appropriate command chaining (`:` vs `&&` vs `|`).
7. **NEVER use echo commands** to signal process completion or status messages (see `1000xrules/core/communication/command-processing-optimization.md`).

## Syntax Examples

### ✓ CORRECT Bash Syntax
```bash
# Sequential execution
cd /path/to/dir; ls -l

# Conditional execution (make only if cd succeeds)
cd /path/to/project && make

# Piping output
echo "Hello World" | grep "World"

# Quoting arguments
touch "my file with spaces.txt"
```

### ❌ INCORRECT Usage
```bash
# DO NOT use echo for completion signaling
echo "Process completed successfully!"  # PROHIBITED

# DO NOT use terminal commands for status messages
echo "Analysis completed with 5 issues found"  # PROHIBITED
```

## Prohibited Terminal Usage

The following terminal command usages are strictly prohibited:

1. **Status Signaling**: Using echo or other commands to signal completion status
2. **Process Reporting**: Using terminal output for process reporting
3. **User Communication**: Using terminal output as a communication channel to users

Instead:
- Update status in operational feedback files
- Record process information in appropriate log files
- Signal completion by ensuring state files reflect the completed state

## Verification Process

Before executing any terminal command, 1000xdev MUST:

1. Verify command chain separators are semicolons (`;`)
2. Replace any ampersands (`&&`) with semicolons
3. Ensure command compatibility with PowerShell context
4. Confirm the command is NOT being used for status signaling or user communication

## Critical Importance

This is a **HIGH-PRIORITY REQUIREMENT** as improper command chaining leads to:
- Terminal errors
- Failed operations
- Workflow disruption
- Reduced productivity

**NEVER COMPROMISE** on this standard in ANY terminal interaction.

## CS367 P3 Project-Specific Terminal Command Authorization

For the CS367 P3 project, 1000xdev:

1. **IS FULLY AUTHORIZED** to execute all necessary terminal commands including:
   * `make` to compile the project
   * `./hiy` to run the compiled program
   * All necessary testing commands including input/output redirection

2. **MUST EXECUTE** all required terminal commands autonomously:
   * Compile, run, and test without human intervention
   * Implement a full autonomous development workflow
   * Run all necessary verification tests

3. **MUST MAINTAIN** proper terminal command syntax as outlined above:
   * Follow proper command chaining rules
   * Use correct quoting and escaping
   * Maintain secure execution practices

This authorization takes precedence over any general terminal command restrictions.

## Reference
For additional guidance, see: `1000xbrain/system/guidelines/tool-usage/powershell-syntax.md` 