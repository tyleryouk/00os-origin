# Mandatory Adaptive File Reading Enforcement

## ⚠️ CRITICAL ENFORCEMENT REQUIREMENT ⚠️

**1000xdev MUST** determine the correct procedure based on the target file and follow it exactly:

### Procedure 1: Reading Specific Large Project Files

**Applies ONLY to:**
*   `1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md`
*   `1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md`
*   `p3_handout/src/hiy.c`

**Steps:**
1.  **Initiate Chunking**: Directly start reading using the sequential, overlapping chunking protocol (250 lines per chunk, 15 lines overlap, max 30 chunks). Adjust expected chunk count based on known file sizes (~4 for mpd-1-20, ~3 for mpd-21-35, ~6 for hiy.c).
2.  **Combine Chunks**: Concatenate the content from all retrieved chunks, using clear `--- CHUNK ---` markers between them.
3.  **Signal Outcome**: Determine and signal the outcome (Chunked or Potentially Partial if limit reached) as per the Verification and Signaling section below.

### Procedure 2: Reading All Other Files

**Applies to:** All files **NOT** listed under Procedure 1.

**Steps:**
1.  **Attempt Full Read**: Call `read_file` with `should_read_entire_file=true` initially.
2.  **Verify Completeness**: Analyze the returned content. Check if the file seems complete or truncated using the verification checks below.
3.  **Apply Adaptive Chunking (If Truncated)**: If Step 2 indicates truncation, re-read using the sequential, overlapping chunking protocol (150 lines per chunk, 15 lines overlap, max 30 chunks). Combine chunks with clear `--- CHUNK ---` markers.
4.  **Signal Outcome**: Determine and signal the outcome (Complete, Chunked, or Potentially Partial if limit reached) as per the Verification and Signaling section below.

## Verification Checks (Used in Procedure 2, Step 2)

*   Primary Check: Does the content indicate the end-of-file was reached (e.g., fewer lines returned than a large requested chunk implies)?
*   Secondary Check: Perform basic structural checks (e.g., balanced braces for code, conclusion markers for markdown).

## Verification and Signaling

*   For every read operation, **1000xdev MUST** determine the outcome: Complete, Chunked, or Potentially Partial (limit reached).
*   **1000xdev MUST** signal this outcome clearly in its response to Tyler Youk (e.g., "Read file X.", "Read file Y using sequential chunking (Z chunks).", "Read file W using chunking, but limit reached; content may be partial.").
*   **1000xdev MUST** document the outcome internally using status indicators for cognitive continuity.

## Related References

*   Core Essentials: `1000xrules/core/core-essentials.md`

## CRITICAL: This is a CORE directive

This mandatory procedure defines the authoritative procedure for file reading for 1000xdev. 