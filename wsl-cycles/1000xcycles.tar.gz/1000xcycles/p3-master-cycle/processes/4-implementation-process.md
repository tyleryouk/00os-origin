# Process: Implementation

## Goal: Implement HIY shell in p3_handout/src/hiy.c with continuous testing

## Steps:

1. **Review Documentation and Current Code**:
   * Access project documentation directly:
   ```
   read_file("p3_strict_instructions/documentation-pages-md/hiy-requirements.md", should_read_entire_file=true)
   read_file("p3_strict_instructions/documentation-pages-md/hiy-specs.md", should_read_entire_file=true)
   ```
   * Examine current hiy.c implementation:
   ```
   read_file("p3_handout/src/hiy.c", should_read_entire_file=true)
   read_file("p3_handout/src/hiy.h", should_read_entire_file=true)
   ```

2. **Check Implementation Plan**:
   * Review implementation plan:
   ```
   read_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_plan.md", should_read_entire_file=true)
   read_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_progress.md", should_read_entire_file=true)
   ```
   * Identify next task to implement

3. **Implement First Phase Tasks**:
   * Implement core shell infrastructure:
   ```
   edit_file("p3_handout/src/hiy.c", "Implement core data structures", "[code implementation without comments]")
   ```
   * Immediately compile and test after each change:
   ```
   run_terminal_cmd(command="cd p3_handout && make", is_background=false)
   run_terminal_cmd(command="cd p3_handout && ./hiy", is_background=false)
   ```
   * Fix any errors before proceeding
   * Update progress after each task:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_progress.md", 
             "Update implementation progress", 
             "// ... existing code ...\n[Update task status]\n// ... existing code ...")
   ```

4. **Implement Second Phase Tasks**:
   * Implement basic command execution:
   ```
   edit_file("p3_handout/src/hiy.c", "Implement built-in commands", "[code implementation without comments]")
   ```
   * Test built-in commands:
   ```
   run_terminal_cmd(command="cd p3_handout && make", is_background=false)
   run_terminal_cmd(command="cd p3_handout && echo -e \"help\nquit\" | ./hiy", is_background=false)
   ```
   * Update progress after each task:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_progress.md", 
             "Update implementation progress", 
             "// ... existing code ...\n[Update task status]\n// ... existing code ...")
   ```

5. **Implement Third Phase Tasks**:
   * Implement advanced process control:
   ```
   edit_file("p3_handout/src/hiy.c", "Implement signal handling", "[code implementation without comments]")
   ```
   * Test process control features:
   ```
   run_terminal_cmd(command="cd p3_handout && make", is_background=false)
   run_terminal_cmd(command="cd p3_handout && echo -e \"start sleep 5\nlist\nquit\" | ./hiy", is_background=false)
   ```
   * Update progress after each task:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_progress.md", 
             "Update implementation progress", 
             "// ... existing code ...\n[Update task status]\n// ... existing code ...")
   ```

6. **Implement Fourth Phase Tasks**:
   * Implement I/O redirection and pipes:
   ```
   edit_file("p3_handout/src/hiy.c", "Implement I/O redirection", "[code implementation without comments]")
   ```
   * Test I/O features:
   ```
   run_terminal_cmd(command="cd p3_handout && make", is_background=false)
   run_terminal_cmd(command="cd p3_handout && echo -e \"start ls > output.txt\nquit\" | ./hiy", is_background=false)
   run_terminal_cmd(command="cd p3_handout && cat output.txt", is_background=false)
   ```
   * Update progress after each task:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_progress.md", 
             "Update implementation progress", 
             "// ... existing code ...\n[Update task status]\n// ... existing code ...")
   ```

7. **Verify No Comments in Code**:
   * Verify no comments were added to the implementation:
   ```
   grep_search(query="^\\s*//", include_pattern="p3_handout/src/hiy.c")
   ```
   * If comments found, remove them:
   ```
   edit_file("p3_handout/src/hiy.c", "Remove comments", "[code with comments removed]")
   ```

8. **Final Testing**:
   * Perform comprehensive testing:
   ```
   run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
   run_terminal_cmd(command="cd p3_handout && echo -e \"help\nstart ls\nstartbg sleep 1\nlist\nquit\" | ./hiy", is_background=false)
   ```
   * Document test results:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_progress.md", 
             "Update test results", 
             "// ... existing code ...\n## Test Results\n\n### Basic Functionality\n* Shell prompt: ✓\n* Command parsing: ✓\n* Built-in commands: ✓\n\n### Process Execution\n* Foreground execution: ✓\n* Background execution: ✓\n* Task management: ✓\n\n### Advanced Features\n* Signal handling: ✓\n* I/O redirection: ✓\n* Pipes: ✓\n// ... existing code ...")
   ```

9. **Update Cycle Status**:
   * Update current cycle status:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/current_cycle.md", 
             "Update cycle status after implementation", 
             "// ... existing code ...\n**Status**: Implementation Complete\n**Current Phase**: Ready for Verification\n\n## Recent Logs\n\n**Implementation**: Completed implementation of HIY shell. All core functionality implemented and tested.\n// ... existing code ...")
   ```

10. **Signal Completion**:
    * Signal completion of implementation
    * Indicate next step: `run:p3-master-cycle/5`

## Critical Project Constraints

**⚠️ CRITICAL PROJECT CONSTRAINTS ⚠️**:
* ONLY `p3_handout/src/hiy.c` may be edited
* NO comments in the implementation
* NO new files should be created

## Error Handling

* If compilation fails, fix errors before proceeding to next task
* If tests fail, debug and fix issues before moving to the next phase
* If updates to progress tracking fail, continue with implementation 