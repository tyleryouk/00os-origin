# Process: Testing

## Goal: Thoroughly test the HIY shell implementation to ensure all requirements are met

## Steps:

1. **Review Project Requirements**:
   * Access project documentation directly:
   ```
   read_file("p3_strict_instructions/documentation-pages-md/hiy-requirements.md", should_read_entire_file=true)
   read_file("p3_strict_instructions/documentation-pages-md/hiy-specs.md", should_read_entire_file=true)
   ```
   * Review testing requirements if available:
   ```
   read_file("p3_strict_instructions/documentation-pages-md/hiy-testing.md", should_read_entire_file=true)
   ```

2. **Examine Implementation**:
   * Read current implementation of hiy.c:
   ```
   read_file("p3_handout/src/hiy.c", should_read_entire_file=true)
   read_file("p3_handout/src/hiy.h", should_read_entire_file=true)
   ```
   * Understand the code structure and functionality

3. **Compile the Code**:
   * Compile the project:
   ```
   run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
   ```
   * Verify successful compilation

4. **Test Basic Commands**:
   * Test help and quit commands:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"help\nquit\" | ./hiy", is_background=false)
   ```
   * Document results

5. **Test Task Management**:
   * Test list and delete commands:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"start echo test\nlist\ndelete 1\nlist\nquit\" | ./hiy", is_background=false)
   ```
   * Document results

6. **Test Process Execution**:
   * Test foreground execution:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"start echo hello\nquit\" | ./hiy", is_background=false)
   ```
   * Test background execution:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"startbg sleep 1\nlist\nquit\" | ./hiy", is_background=false)
   ```
   * Document results

7. **Test I/O Redirection**:
   * Test input redirection:
   ```
   run_terminal_cmd(command="cd p3_handout && echo 'test input' > test_input.txt && echo -e \"start cat < test_input.txt\nquit\" | ./hiy", is_background=false)
   ```
   * Test output redirection:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"start echo test > test_output.txt\nquit\" | ./hiy", is_background=false)
   run_terminal_cmd(command="cd p3_handout && cat test_output.txt", is_background=false)
   ```
   * Document results

8. **Test Pipe Functionality**:
   * Test pipe between processes:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"start ls | grep Make\nquit\" | ./hiy", is_background=false)
   ```
   * Document results

9. **Test Process Control**:
   * Test fg/bg commands:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"startbg sleep 2\nlist\nfg 1\nquit\" | ./hiy", is_background=false)
   ```
   * Test kill command:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"startbg sleep 10\nlist\nkill 1\nlist\nquit\" | ./hiy", is_background=false)
   ```
   * Document results

10. **Create Test Report**:
    * Document test results:
    ```
    edit_file("1000xcycles/p3-master-cycle/operational_feedback/test_report.md", 
              "Create test report", 
              "# Test Report\n\n**Date**: [current-date]\n\n## Summary\n\nThis report documents the test results for the HIY shell implementation.\n\n## Test Results\n\n### Basic Shell Features\n\n* **Help Command**: [PASS/FAIL]\n* **Quit Command**: [PASS/FAIL]\n* **Command Parsing**: [PASS/FAIL]\n\n### Task Management\n\n* **List Command**: [PASS/FAIL]\n* **Delete Command**: [PASS/FAIL]\n\n### Process Execution\n\n* **Foreground Execution**: [PASS/FAIL]\n* **Background Execution**: [PASS/FAIL]\n\n### I/O Redirection\n\n* **Input Redirection**: [PASS/FAIL]\n* **Output Redirection**: [PASS/FAIL]\n\n### Pipe Functionality\n\n* **Pipe Between Processes**: [PASS/FAIL]\n\n### Process Control\n\n* **FG Command**: [PASS/FAIL]\n* **BG Command**: [PASS/FAIL]\n* **Kill Command**: [PASS/FAIL]\n\n## Issues Found\n\n* [List any issues found during testing or 'No issues found']\n\n## Overall Status\n\n* **Testing Status**: [PASS/FAIL]\n\n## Next Steps\n\n* [Recommendations based on test results]")
    ```

11. **Update Cycle Status**:
    * Update status to reflect testing completion:
    ```
    edit_file("1000xcycles/p3-master-cycle/operational_feedback/current_cycle.md", 
              "Update cycle status after testing", 
              "// ... existing code ...\n**Status**: Testing Complete\n**Current Phase**: Ready for Verification\n\n## Recent Logs\n\n**Testing**: Completed testing of HIY shell implementation. All features tested with results documented in test report.\n// ... existing code ...")
    ```

12. **Signal Completion**:
    * Signal completion of testing
    * Indicate next step: `run:p3-master-cycle/5`

## Critical Project Constraints

**⚠️ CRITICAL PROJECT CONSTRAINTS ⚠️**:
* ONLY `p3_handout/src/hiy.c` may be edited
* NO comments in the implementation
* NO new files should be created

## Error Handling

* If compilation fails, document errors and recommend returning to implementation
* If tests fail, document specific failures and suggest fixes
* If any test is inconclusive, document the issue and recommend additional testing 