# Process: Verification

## Goal: Verify HIY shell implementation meets all requirements and constraints

## Steps:

1. **Review Project Requirements**:
   * Access project documentation directly:
   ```
   read_file("p3_strict_instructions/documentation-pages-md/hiy-requirements.md", should_read_entire_file=true)
   read_file("p3_strict_instructions/documentation-pages-md/hiy-specs.md", should_read_entire_file=true)
   ```
   * If necessary, check additional documentation:
   ```
   read_file("p3_strict_instructions/documentation-pages-md/hiy-testing.md", should_read_entire_file=true)
   ```

2. **Examine Implementation**:
   * Read current implementation of hiy.c:
   ```
   read_file("p3_handout/src/hiy.c", should_read_entire_file=true)
   ```
   * Examine implementation plan and progress:
   ```
   read_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_plan.md", should_read_entire_file=true)
   read_file("1000xcycles/p3-master-cycle/operational_feedback/implementation_progress.md", should_read_entire_file=true)
   ```

3. **Verify Project Constraints**:
   * Check for comments in the code:
   ```
   grep_search(query="^\\s*//|/\\*", include_pattern="p3_handout/src/hiy.c")
   ```
   * Verify only hiy.c was modified:
   ```
   run_terminal_cmd(command="cd p3_handout/src && ls -la", is_background=false)
   ```
   * Check no new files were created:
   ```
   run_terminal_cmd(command="cd p3_handout && find . -type f -newer Makefile | grep -v 'hiy.c\\|hiy'", is_background=false)
   ```

4. **Compilation Test**:
   * Compile the code:
   ```
   run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
   ```
   * Check for compilation errors and warnings

5. **Functionality Testing**:
   * Test basic commands:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"help\nquit\" | ./hiy", is_background=false)
   ```
   * Test process execution:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"start echo hello\nlist\nquit\" | ./hiy", is_background=false)
   ```
   * Test background execution:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"startbg sleep 1\nlist\nquit\" | ./hiy", is_background=false)
   ```
   * Test I/O redirection:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"start echo test > output.txt\nquit\" | ./hiy", is_background=false)
   run_terminal_cmd(command="cd p3_handout && cat output.txt", is_background=false)
   ```
   * Test pipe functionality:
   ```
   run_terminal_cmd(command="cd p3_handout && echo -e \"start ls | grep Make\nquit\" | ./hiy", is_background=false)
   ```

6. **Create Verification Report**:
   * Document verification results:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/verification_report.md", 
             "Create comprehensive verification report", 
             "# Verification Report\n\n**Date**: [current-date]\n\n## Summary\n\nThis report documents the verification results for the HIY shell implementation.\n\n## Project Constraints Verification\n\n* **Comment Check**: [PASS/FAIL] - No new comments added to the implementation\n* **File Modification**: [PASS/FAIL] - Only hiy.c was modified\n* **No New Files**: [PASS/FAIL] - No new files were created\n\n## Compilation Test\n\n* **Compilation**: [PASS/FAIL] - Code compiles without errors\n* **Warnings**: [None/List warnings if any]\n\n## Functionality Testing\n\n### Basic Shell Features\n\n* **Shell Prompt**: [PASS/FAIL] - Shell displays the prompt correctly\n* **Command Parsing**: [PASS/FAIL] - Shell parses commands correctly\n* **Built-in Commands**: [PASS/FAIL] - All built-in commands work as expected\n\n### Process Execution\n\n* **Foreground Execution**: [PASS/FAIL] - start command works correctly\n* **Background Execution**: [PASS/FAIL] - startbg command works correctly\n* **Task Management**: [PASS/FAIL] - list, kill, etc. commands work correctly\n\n### Advanced Features\n\n* **I/O Redirection**: [PASS/FAIL] - Input and output redirection work correctly\n* **Pipe Functionality**: [PASS/FAIL] - Pipes between processes work correctly\n* **Signal Handling**: [PASS/FAIL] - Shell handles signals appropriately\n\n## Issues Found\n\n* [List any issues found during verification or 'No issues found']\n\n## Overall Status\n\n* **Verification Status**: [PASS/FAIL]\n\n## Next Steps\n\n* [Recommendations based on verification results]")
   ```

7. **Update Cycle Status**:
   * Update status based on verification results:
   ```
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/current_cycle.md", 
             "Update cycle status after verification", 
             "// ... existing code ...\n**Status**: Verification Complete\n**Current Phase**: Ready for Documentation\n\n## Recent Logs\n\n**Verification**: Completed verification of HIY shell implementation. All project constraints and functional requirements verified.\n// ... existing code ...")
   ```

8. **Signal Completion**:
   * Signal completion of verification
   * Indicate next step: `run:p3-master-cycle/6`

## Critical Project Constraints

**⚠️ CRITICAL PROJECT CONSTRAINTS ⚠️**:
* ONLY `p3_handout/src/hiy.c` may be edited
* NO comments in the implementation
* NO new files should be created

## Error Handling

* If documentation files cannot be accessed, search for alternative locations
* If compilation fails, document errors and recommend returning to implementation
* If functionality tests fail, document specific failures and recommend fixes 