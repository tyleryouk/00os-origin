# HIY Shell Implementation Testing Workflow

## Updated Testing Process

We have established a collaborative testing workflow:

1. **Test Planning Phase**: 
   - I'll add systematic test cases to `test_results.md`
   - Tests are organized by feature category with clear instructions
   - Each section includes placeholders for terminal output and observations

2. **Test Execution Phase**:
   - You will run the HIY shell from the terminal: `./hiy`
   - You'll enter the test commands at the HIY$ prompt exactly as listed
   - You'll capture the output and paste it back into `test_results.md`
   - You'll note any observations about unexpected behavior

3. **Analysis & Implementation Phase**:
   - I'll analyze the test results and identify issues
   - For each issue identified, I'll recommend specific fixes
   - I'll modify `p3_handout/src/hiy.c` as needed or propose new test cases
   - We'll repeat the cycle as needed until all tests pass

## Test Categories

Our comprehensive test plan in `test_results.md` covers:

1. **Basic Functionality Tests**: help, list, task creation/deletion
2. **Task Execution Tests**: foreground and background process execution
3. **File Redirection Tests**: input/output redirection to files
4. **Pipe Tests**: connecting tasks through pipes
5. **Process Control Tests**: kill, suspend, resume operations
6. **Signal Handling Tests**: keyboard signals (Ctrl-C, Ctrl-Z, Ctrl-\)
7. **Edge Case Tests**: boundary conditions and error handling

## Critical Implementation Notes

- **File Restrictions**: Only `p3_handout/src/hiy.c` should be modified
- **No Comments**: Per project requirements, no comments should be added to the implementation
- **Signal Handling**: Special attention to proper signal blocking/unblocking
- **Memory Management**: Ensure no memory leaks in task creation/deletion
- **Error Handling**: Verify proper logging of all error conditions
- **Process Groups**: Check that each child process sets its own process group

## Guidance from MPD

Based on the Master Project Documentation (MPD):
- Task numbers start at 1 and increment for each new task (never reused)
- Six possible task states: Ready, Run FG, Run BG, Suspended, Finished, Killed
- Maximum one foreground task at a time, any number of background tasks
- Commands must be checked in both `./ ` and `/usr/bin/` directories
- All output must use the provided logging functions

The documentation includes numerous example runs which serve as our reference for expected behavior.

## Priority Context Files

### Essential Files (Always Use):
* p3_handout/src/hiy.c - The implementation file (ONLY file you will be editing)
* 1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md - Contains all test commands and CRITICAL GRADING EXAMPLES

### Secondary Reference (Use as Needed):
* 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md - Master Project Documentation Part 1
* 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md - Master Project Documentation Part 2

### Supplementary tests with fox.txt:
* p3_handout/fox.txt

## Testing Recommendations

1. Start with basic functionality tests (help, list, task creation)
2. Progress to task execution tests (start, startbg)
3. Test file redirection and piping
4. Test process control (fg, bg, kill, suspend)
5. Test signal handling (Ctrl-C, Ctrl-Z, Ctrl-\)

REMEMBER: Only edit p3_handout/src/hiy.c - NO other files should be modified.

## Test Session 1: Basic Functionality

### 1. Basic Command Creation and Management

```
HIY$ ls -al
[HIY-LOG] Adding Task ID 1: ls -al (Ready)
HIY$ cat fox.txt
[HIY-LOG] Adding Task ID 2: cat fox.txt (Ready)
HIY$ list
[HIY-LOG] 2 Task(s)
[HIY-LOG] Task 1: ls -al (Ready)
[HIY-LOG] Task 2: cat fox.txt (Ready)
```

Commands are being correctly registered in the task list

### 2. Starting a Task

```
HIY$ start 1
[HIY-LOG] Process 1064343 (Task 1; ls -al) changed from Ready to Running FG (Started)
total 524
drwxr-xr-x 5 root root   4096 Mar 25 18:30 .
drwxr-xr-x 8 root root   4096 Mar 25 18:30 ..
-rw-r--r-- 1 root root     74 Mar 25 18:30 fox.txt
drwxr-xr-x 2 root root   4096 Mar 25 18:30 inc
-rw-r--r-- 1 root root   1178 Mar 25 18:30 Makefile
-rwxr-xr-x 1 root root 481224 Mar 25 18:30 my_echo
-rwxr-xr-x 1 root root   7992 Mar 25 18:30 my_pause
drwxr-xr-x 2 root root   4096 Mar 25 18:30 obj
-rwxr-xr-x 1 root root   8016 Mar 25 18:30 slow_cooker
drwxr-xr-x 2 root root   4096 Mar 25 18:30 src
[HIY-LOG] Foreground Process 1064343 (Task 1; ls -al) changed from Running FG to Finished (Terminated Normally)
HIY$ start 2
[HIY-LOG] Process 1064378 (Task 2; cat fox.txt) changed from Ready to Running FG (Started)
the quick brown fox jumps over the lazy dog
once upon a time in unix land
hello world
the lazy programmer
computer science 367
[HIY-LOG] Foreground Process 1064378 (Task 2; cat fox.txt) changed from Running FG to Finished (Terminated Normally)
```

Basic foreground task execution works as expected

### 3. Background Tasks

```
HIY$ slow_cooker 5
[HIY-LOG] Adding Task ID 3: slow_cooker 5 (Ready)
HIY$ startbg 3
[HIY-LOG] Process 1064390 (Task 3; slow_cooker 5) changed from Ready to Running BG (Started)
HIY$ [PID: 1064390] slow_cooker count down: 5 ...
[PID: 1064390] slow_cooker count down: 4 ...
[PID: 1064390] slow_cooker count down: 3 ...
[PID: 1064390] slow_cooker count down: 2 ...
[PID: 1064390] slow_cooker count down: 1 ...
[PID: 1064390] slow_cooker count down: 0 ...
[HIY-LOG] Background Process 1064390 (Task 3; slow_cooker 5) changed from Running BG to Finished (Terminated Normally)
```

Background execution works correctly

### 4. File Redirection Testing

```
HIY$ grep the
[HIY-LOG] Adding Task ID 4: grep the (Ready)
HIY$ start 4 < fox.txt
[HIY-LOG] Process 1064402 (Task 4; grep the) changed from Ready to Running FG (Started)
[HIY-LOG] Redirecting input from fox.txt for Task 4
the quick brown fox jumps over the lazy dog
the lazy programmer
[HIY-LOG] Foreground Process 1064402 (Task 4; grep the) changed from Running FG to Finished (Terminated Normally)

HIY$ start 1 > output.txt
[HIY-LOG] Process 1064421 (Task 1; ls -al) changed from Finished to Running FG (Started)
[HIY-LOG] Redirecting output to output.txt for Task 1
[HIY-LOG] Foreground Process 1064421 (Task 1; ls -al) changed from Running FG to Finished (Terminated Normally)
```

File redirection seems to be working properly

### 5. Pipe Testing

```
HIY$ cat fox.txt
[HIY-LOG] Adding Task ID 5: cat fox.txt (Ready)
HIY$ grep the
[HIY-LOG] Adding Task ID 6: grep the (Ready)
HIY$ pipe 5 6
[HIY-LOG] Opening a pipe from Task 5 to Task 6
[HIY-LOG] Process 1064443 (Task 5; cat fox.txt) changed from Ready to Running BG (Started)
[HIY-LOG] Process 1064444 (Task 6; grep the) changed from Ready to Running FG (Started)
the quick brown fox jumps over the lazy dog
the lazy programmer
[HIY-LOG] Background Process 1064443 (Task 5; cat fox.txt) changed from Running BG to Finished (Terminated Normally)
[HIY-LOG] Foreground Process 1064444 (Task 6; grep the) changed from Running FG to Finished (Terminated Normally)
```

Pipe functionality works correctly

### 6. Process Control

```
HIY$ sleep 100
[HIY-LOG] Adding Task ID 7: sleep 100 (Ready)
HIY$ startbg 7
[HIY-LOG] Process 1064452 (Task 7; sleep 100) changed from Ready to Running BG (Started)
HIY$ kill 7
[HIY-LOG] Cancel message sent to Task ID 7 (PID 1064452)
HIY$ [HIY-LOG] Background Process 1064452 (Task 7; sleep 100) changed from Running BG to Killed (Terminated by Signal)

HIY$ slow_cooker 10
[HIY-LOG] Adding Task ID 8: slow_cooker 10 (Ready)
HIY$ startbg 8
[HIY-LOG] Process 1064461 (Task 8; slow_cooker 10) changed from Ready to Running BG (Started)
HIY$ [PID: 1064461] slow_cooker count down: 10 ...
[PID: 1064461] slow_cooker count down: 9 ...
suspend 8
[HIY-LOG] Suspend message sent to Task ID 8 (PID 1064461)
HIY$ [HIY-LOG] Background Process 1064461 (Task 8; slow_cooker 10) changed from Running BG to Suspended (Stopped)

HIY$ fg 8
[HIY-LOG] Resume message sent to Task ID 8 (PID 1064461)
HIY$ [HIY-LOG] Process 1064461 (Task 8; slow_cooker 10) changed from Suspended to Running FG (Continued)
[PID: 1064461] slow_cooker count down: 8 ...
[PID: 1064461] slow_cooker count down: 7 ...
[PID: 1064461] slow_cooker count down: 6 ...
[PID: 1064461] slow_cooker count down: 5 ...
[PID: 1064461] slow_cooker count down: 4 ...
[PID: 1064461] slow_cooker count down: 3 ...
[PID: 1064461] slow_cooker count down: 2 ...
[PID: 1064461] slow_cooker count down: 1 ...
[PID: 1064461] slow_cooker count down: 0 ...
[HIY-LOG] Foreground Process 1064461 (Task 8; slow_cooker 10) changed from Running FG to Finished (Terminated Normally)
```

Process control commands seem to work correctly

### 7. Delete Command

```
HIY$ list
[HIY-LOG] 8 Task(s)
[HIY-LOG] Task 1: ls -al (PID 1064421; Finished; exit code 0)
[HIY-LOG] Task 2: cat fox.txt (PID 1064378; Finished; exit code 0)
[HIY-LOG] Task 3: slow_cooker 5 (PID 1064390; Finished; exit code 5)
[HIY-LOG] Task 4: grep the (PID 1064402; Finished; exit code 0)
[HIY-LOG] Task 5: cat fox.txt (PID 1064443; Finished; exit code 0)
[HIY-LOG] Task 6: grep the (PID 1064444; Finished; exit code 0)
[HIY-LOG] Task 7: sleep 100 (PID 1064452; Killed; exit code 0)
[HIY-LOG] Task 8: slow_cooker 10 (PID 1064461; Finished; exit code 10)

HIY$ delete 7
[HIY-LOG] Deleting Task ID 7
HIY$ delete 5
[HIY-LOG] Deleting Task ID 5
HIY$ delete 20
[HIY-LOG] Error: Task 20 Not Found in Task List
```

Delete command works as expected

## Issues to Test Further:

1. Keyboard signal handling (Ctrl+C, Ctrl+Z, Ctrl+\)
2. Task switching with Ctrl+\ 
3. Edge cases like invalid commands and full task list
4. Running processes when trying to quit
5. Error cases with file operations
6. Complex pipe operations and error handling