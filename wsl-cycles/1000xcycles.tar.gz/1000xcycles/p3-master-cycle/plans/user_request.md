# USER REQUEST File
# This file is exclusively for storing USER REQUEST content to be read and processed by 1000xdev.
# Notes and personal content should be kept in notes.md.

## USER REQUEST SECTION

# --- OPERATION MODE ---
 USER_DIRECTED_MODE

# --- REQUEST DETAILS ---
# Directive: Implementation
# Target Cycle: p3-master-cycle
# Implementation Name: Hash It Yourself (HIY) Implementation
# Priority: High

# Implementation Details

## ⚠️ CRITICAL PROCESS ⚠️

Iterate on the following process until all test cases pass:

1. Compile the HIY shell in p3_handout directory:
   ```bash
   cd p3_handout
   make clean
   make
   ```

2. Enter the HIY shell:
   ```bash
   ./hiy
   ```

3. Test the HIY shell commands directly at the HIY$ prompt:
   * Test one example at a time from the CRITICAL GRADING EXAMPLES section in hiy-shell-commands.md
   * Enter each command at the HIY$ prompt EXACTLY as shown
   * Verify output matches expected results
   * Stay in the HIY shell during testing

4. When issues are found:
   * Keep the HIY shell running in one terminal
   * Open a second terminal or editor to edit p3_handout/src/hiy.c
   * Make necessary code changes to fix identified issues
   * Save the changes

5. In a new terminal, compile the updated code:
   ```bash
   cd p3_handout
   make
   ```

6. Exit the current HIY shell instance using the `quit` command
   ```
   HIY$ quit
   ```

7. Start a new HIY shell instance to test the changes:
   ```bash
   ./hiy
   ```

8. Repeat steps 3-7 until all test cases pass successfully

## Priority Context Files

### Essential Files (Always Use):
* p3_handout/src/hiy.c - The implementation file (ONLY file you will be editing)
* 1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md - Contains all test commands and CRITICAL GRADING EXAMPLES

### Secondary Reference (Use as Needed):
* 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md - Master Project Documentation Part 1
* 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md - Master Project Documentation Part 2

### Supplementary (Only If Previous Files Are Insufficient):
* 1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md
* 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/all-examples-runs.md

## Testing Recommendations

1. Start with basic functionality tests (help, list, task creation)
2. Progress to task execution tests (start, startbg)
3. Test file redirection and piping
4. Test process control (fg, bg, kill, suspend)
5. Test signal handling (Ctrl-C, Ctrl-Z, Ctrl-\)

REMEMBER: Only edit p3_handout/src/hiy.c - NO other files should be modified.

# Focus Areas

# --- DIRECTIVE REFERENCE ---
# Implementation: Implement functionality according to project requirements
# Fix: Correct problems or issues in existing functionality
# Refactor: Restructure code without changing functionality
# Analysis: Evaluate component(s) without making changes

# --- MODE REFERENCE ---
# AUTONOMOUS_MODE: System selects and implements enhancements with minimal user intervention
# USER_DIRECTED_MODE: System implements exactly what's specified and waits for explicit direction
# --- TEMPLATE END ---

## END USER REQUEST SECTION
