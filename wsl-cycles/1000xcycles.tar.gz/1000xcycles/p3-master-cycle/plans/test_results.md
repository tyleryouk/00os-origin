# HIY Shell Test Results

## 1. Basic Functionality Tests

### Commands to Run:
```
help
list

# Create tasks
ls -al
cat fox.txt
cal -3
slow_cooker 5

# List tasks
list

# Delete a task
delete 2

# Try to delete a non-existent task
delete 10

# List tasks after deletion
list
```

### Terminal Output:
```
HIY$ help 

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = help 
[DEBUG] instruction = "help"
[DEBUG] -----------------------
[HIY-LOG] Instructions:
[HIY-LOG]     COMMAND [ARGS...],
[HIY-LOG]     help, quit, list, delete TASK,
[HIY-LOG]     start TASK [< INFILE] [> OUTFILE],
[HIY-LOG]     startbg TASK [< INFILE] [> OUTFILE],
[HIY-LOG]     kill TASK, suspend TASK,
[HIY-LOG]     fg TASK, bg TASK,
[HIY-LOG]     pipe TASK1 TASK2
[HIY-LOG] 
[HIY-LOG] Brackets denote optional arguments
HIY$ list

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = list
[DEBUG] instruction = "list"
[DEBUG] -----------------------
[HIY-LOG] 1 Task(s)
[HIY-LOG] Task 1: sleep 10 (Ready)
HIY$ ls -al

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = ls -al
[DEBUG] instruction = "ls"
[DEBUG] argv[0] == ls
[DEBUG] argv[1] == -al
[DEBUG] -----------------------
[HIY-LOG] Adding Task ID 2: ls -al (Ready)
HIY$ cat fox.txt

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = cat fox.txt
[DEBUG] instruction = "cat"
[DEBUG] argv[0] == cat
[DEBUG] argv[1] == fox.txt
[DEBUG] -----------------------
[HIY-LOG] Adding Task ID 3: cat fox.txt (Ready)
HIY$ cal -3

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = cal -3
[DEBUG] instruction = "cal"
[DEBUG] argv[0] == cal
[DEBUG] argv[1] == -3
[DEBUG] -----------------------
[HIY-LOG] Adding Task ID 4: cal -3 (Ready)
HIY$ slow_cooker 5

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = slow_cooker 5
[DEBUG] instruction = "slow_cooker"
[DEBUG] argv[0] == slow_cooker
[DEBUG] argv[1] == 5
[DEBUG] -----------------------
[HIY-LOG] Adding Task ID 5: slow_cooker 5 (Ready)
HIY$ list

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = list
[DEBUG] instruction = "list"
[DEBUG] -----------------------
[HIY-LOG] 5 Task(s)
[HIY-LOG] Task 1: sleep 10 (Ready)
[HIY-LOG] Task 2: ls -al (Ready)
[HIY-LOG] Task 3: cat fox.txt (Ready)
[HIY-LOG] Task 4: cal -3 (Ready)
[HIY-LOG] Task 5: slow_cooker 5 (Ready)
HIY$ delete 2

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = delete 2
[DEBUG] instruction = "delete"
[DEBUG] task number = 2
[DEBUG] -----------------------
[HIY-LOG] Deleting Task ID 2
HIY$ delete 10

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = delete 10
[DEBUG] instruction = "delete"
[DEBUG] task number = 10
[DEBUG] -----------------------
[HIY-LOG] Error: Task 10 Not Found in Task List
HIY$ list

[DEBUG] -----------------------
[DEBUG] - Main, after parse
[DEBUG] -----------------------
[DEBUG] cmdline     = list
[DEBUG] instruction = "list"
[DEBUG] -----------------------
[HIY-LOG] 4 Task(s)
[HIY-LOG] Task 1: sleep 10 (Ready)
[HIY-LOG] Task 3: cat fox.txt (Ready)
[HIY-LOG] Task 4: cal -3 (Ready)
[HIY-LOG] Task 5: slow_cooker 5 (Ready)
HIY$ 
```

### Issues and Observations:
- 

## 2. Task Execution Tests

### Commands to Run:
```
# Start a task in foreground
start 1

# Create a task with invalid command
delicious pancakes
list

# Start the invalid command
start 4

# Try an executable that should work
ls -l
start 5

# Test background execution
slow_cooker 10
startbg 6
list
```

### Terminal Output:
```
[Paste terminal output here]
```

### Issues and Observations:
- 

## 3. File Redirection Tests

### Commands to Run:
```
# Create tasks for redirection
grep the
cat

# Input redirection
start 7 < fox.txt

# Output redirection
start 5 > output.txt

# Both input and output redirection
cat
start 9 < fox.txt > combined_output.txt
```

### Terminal Output:
```
[Paste terminal output here]
```

### Issues and Observations:
- 

## 4. Pipe Tests

### Commands to Run:
```
# Create tasks for pipe testing
cat fox.txt
grep the
wc -l

# Test piping between tasks
pipe 10 11
pipe 10 12
```

### Terminal Output:
```
[Paste terminal output here]
```

### Issues and Observations:
- 

## 5. Process Control Tests

### Commands to Run:
```
# Create tasks for process control
sleep 100
slow_cooker 15

# Start a background process
startbg 13

# Kill a running background process
kill 13
list

# Start a process and suspend it
startbg 14
list
suspend 14
list

# Resume in foreground
fg 14

# Resume in background
# First suspend again with Ctrl-Z
bg 14
list
```

### Terminal Output:
```
[Paste terminal output here]
```

### Issues and Observations:
- 

## 6. Signal Handling Tests

### Commands to Run:
```
# Create a long-running task
sleep 30

# Start in foreground
start 1

# Press Ctrl-C to terminate
# [The user would press Ctrl-C here]

# Create a slow_cooker task
slow_cooker 20
start 2

# Press Ctrl-Z to suspend
# [The user would press Ctrl-Z here]
list

# Create multiple tasks for testing Ctrl-\
ls
sleep 20
slow_cooker 10

# Start the third task
start 3

# Press Ctrl-\ to cycle tasks
# [The user would press Ctrl-\ here]
```

### Terminal Output:
```

```

### Issues and Observations:
- 

## 7. Edge Case Tests

### Commands to Run:
```
# Try to delete a busy task
sleep 10
startbg 21
delete 21

# Try to start a non-existent task
start 50

# Try to suspend a task that's already suspended
slow_cooker 5
startbg 22
suspend 22
suspend 22  

# Try to kill a non-running task
kill 1

# Pipe to the same task
pipe 1 1

# Try backgrounding a foreground task
sleep 15
start 25
bg 25  # This should fail
```

### Terminal Output:
```
[Paste terminal output here]
```

### Issues and Observations:
- 

## Summary of All Issues

1. 
2. 
3. 

## Potential Fixes for hiy.c

1. 
2. 
3. 
