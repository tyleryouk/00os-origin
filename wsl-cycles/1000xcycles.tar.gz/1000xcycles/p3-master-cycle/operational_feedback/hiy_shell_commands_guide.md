# HIY Shell Commands Guide for Testing Process

## Overview

This guide explains how to effectively use the `hiy-shell-commands.md` document during Step 8 of the p3-master-cycle testing process to thoroughly test your HIY shell implementation.

## ⚠️ CRITICAL HIY SHELL USAGE INSTRUCTIONS ⚠️

1. **Proper HIY Command Execution:**
   * Only enter HIY commands AFTER you see the HIY$ prompt
   * Enter commands ONE AT A TIME
   * WAIT for each command to complete before entering the next one
   * DO NOT use any bash constructs within the HIY shell (no pipes, &&, ;, etc.)

2. **Required Command Format:**
   * Commands should EXACTLY match those in the test document
   * DO NOT use bash built-ins like cd, echo, export, etc. while in HIY shell
   * Use ONLY commands documented in hiy-shell-commands.md

3. **Exiting the HIY Shell Properly:**
   * Always exit using the `quit` command
   * NEVER use Ctrl-C to exit (that will test signal handling, not exit the shell)
   * Proper exit sequence:
     ```
     HIY$ quit
     [HIY-LOG] Thanks for using the HIY Task Manager! Good-bye!
     root@ETH:~/gmu/cs367/p3/p3_handout#
     ```

4. **Handling Test Sequences:**
   * For test sequences requiring Ctrl-C, Ctrl-Z, or Ctrl-\ input, make sure to:
     - Set up the command sequence as documented
     - Press the keyboard combination at the appropriate time
     - Verify the expected behavior occurs
   * Always use the `list` command to verify the state of tasks after operations

## ⚠️ CRITICAL PROJECT CONSTRAINTS ⚠️

1. **Strict File Editing Limitation**:
   * ONLY `p3_handout/src/hiy.c` may be edited
   * All other project files are READ-ONLY

2. **Comment Prohibition**:
   * NO comments should be added during implementation
   * Comments will be handled in a separate dedicated cycle

3. **No New Files**:
   * NO new files should be created for the project
   * Work exclusively with existing files

## Using the HIY Shell Commands File for Testing

The `1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md` file contains comprehensive test commands extracted directly from the Master Project Documentation (MPD). Follow these steps to effectively use it during testing:

1. **Compile the Current Implementation**:
   ```bash
   cd p3_handout
   make clean
   make
   ```

2. **Launch the HIY Shell**:
   ```bash
   ./hiy
   ```

3. **Execute Test Commands**:
   * Use the command sequences from `hiy-shell-commands.md` as a structured testing plan
   * Enter commands DIRECTLY at the HIY$ prompt one at a time
   * Test each category of functionality (basic commands, task execution, file redirection, etc.)
   * Verify output matches expected results as described in the documentation

4. **Document Test Results**:
   * Track which tests pass and which fail
   * Document any unexpected behavior or errors
   * Update the testing status in the operational feedback files

## Recommended Testing Workflow

1. **Start with Basic Functionality**:
   * Test basic built-in commands (help, list, delete)
   * Test task creation and management
   * Test simple process execution

2. **Progress to More Complex Features**:
   * Test file redirection
   * Test pipe commands
   * Test process control (fg, bg, kill, suspend)

3. **Test Edge Cases and Error Handling**:
   * Test invalid commands and inputs
   * Test boundary conditions
   * Test error recovery

4. **Test Signal Handling**:
   * Test keyboard signals (Ctrl-C, Ctrl-Z, Ctrl-\)
   * Test signal propagation and handling

## Modifying the Test Commands

You are authorized to edit the `hiy-shell-commands.md` file to:

1. **Add Additional Tests**:
   * Create new test cases for edge cases
   * Add tests for specific functionality that needs more coverage
   * Develop tests for any issues discovered during implementation

2. **Update Command Syntax**:
   * Correct any command syntax issues
   * Improve clarity of test instructions
   * Add more detailed expected output descriptions

3. **Enhance Test Organization**:
   * Group related tests together
   * Create new test categories if needed
   * Add cross-references to relevant sections in the MPD

## Keyboard Signal Testing Notes

When testing keyboard signals:

* For Ctrl-C, Ctrl-Z, and Ctrl-\ tests, you'll need to manually press these key combinations
* Ensure your terminal is correctly configured to send these signals
* Verify the expected behavior after each signal is sent

## Completing the Testing Process

After completing all tests:

1. Document the final testing status in `1000xcycles/p3-master-cycle/operational_feedback/current_cycle.md`
2. If all tests pass, proceed to verification phase
3. If tests fail, return to implementation phase to fix issues
4. Ensure all test observations are thoroughly documented

Remember that thorough testing is critical to ensuring your HIY shell implementation meets all project requirements. 