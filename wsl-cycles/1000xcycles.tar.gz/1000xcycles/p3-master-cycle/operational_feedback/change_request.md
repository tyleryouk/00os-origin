# Change Request

**Status**: Analysis Complete

## Request Description

Implement the HIY shell functionality by modifying p3_handout/src/hiy.c according to the project specifications.

## Requirements

1. **Shell Infrastructure**:
   * Command line parsing and execution
   * Support for built-in commands
   * Interactive shell prompt

2. **Task Management**:
   * Maintain a list of tasks
   * Support foreground and background execution
   * Track task status and exit codes

3. **Process Handling**:
   * Execute commands using fork and exec
   * Handle file redirection
   * Implement pipes between processes

4. **Signal Handling**:
   * Handle keyboard signals appropriately
   * Track child process state changes

## Constraints

**⚠️ CRITICAL PROJECT CONSTRAINTS ⚠️**:
* ONLY `p3_handout/src/hiy.c` may be edited
* NO comments in the implementation
* NO new files should be created

## Success Criteria

* Code compiles without errors
* All features work as specified in documentation
* All test cases pass
* Code meets all project constraints

## Special Considerations

1. **Process Management**: Implementation must handle process creation, monitoring, and control properly.
2. **Signal Handling**: Proper handling of signals (SIGINT, SIGTSTP) is required.
3. **Memory Management**: Implementation must handle memory allocation/deallocation properly.
4. **Error Handling**: All error conditions must be properly handled as specified.
5. **Documentation Phase**: Comments must be added in a separate documentation phase, not during initial implementation.
6. **Boundary Respect**: Implementation must respect the boundary between p3-master-cycle and system-cycle-manager.

## Technical Insights

Based on the header files and project structure:

1. **Core Files**:
   * hiy.c: Main shell implementation (to be modified)
   * hiy.h: Main header file with constants
   * parse.h: Command parsing interface
   * util.h: Utility functions
   * logging.h: Logging and output functions

2. **Key Functions/Structures**:
   * Instruction struct: Holds parsed command information
   * parse(): Parses user input into command structures
   * initialize_command()/free_command(): Setup/cleanup functions
   * Logging functions for various shell interactions

3. **Required Commands**:
   * quit: Exit the shell
   * help: Display help information
   * list: List all tasks
   * delete: Delete a task
   * start/startbg: Start tasks in foreground/background
   * kill: Terminate a task
   * suspend: Suspend a running task
   * fg/bg: Move tasks to foreground/background
   * pipe: Create a pipe between tasks

## Timeline

To be populated after planning (Step 3)

## Acceptance Criteria

To be populated after requirement analysis (Step 2)

## References

Project documentation in `p3_strict_instructions/documentation-pages-md/` 