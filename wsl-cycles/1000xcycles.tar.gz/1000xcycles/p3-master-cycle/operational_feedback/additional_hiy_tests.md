# Additional HIY Shell Test Cases

This document contains additional test cases that can be added to the `1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md` file to enhance test coverage during Step 8 of the p3-master-cycle testing process.

## Edge Case Tests

### Multiple Simultaneous Background Processes

```
# Create multiple long-running tasks
slow_cooker 10
slow_cooker 15
slow_cooker 20

# Start all in background
startbg 1
startbg 2
startbg 3

# List tasks to verify all are running
list

# Kill one process while others continue
kill 2

# List tasks to verify status
list

# Wait for processes to complete
# You should see completion messages for tasks 1 and 3
```

### Maximum Task Creation

```
# Create a large number of tasks (testing task management capacity)
ls
cal
echo test
sleep 1
cat fox.txt
grep test
my_echo 5
my_echo 10
my_echo 15
slow_cooker 1

# List all tasks
list

# Delete tasks in various states
delete 3
delete 7

# List tasks again
list
```

### Error Handling Tests

```
# Test invalid task numbers
start 999
fg 999
bg 999
kill 999
suspend 999
delete 999

# Test invalid commands
invalid_command
123456

# Test invalid file paths
start 1 < nonexistent_file.txt
start 1 > /invalid/path/file.txt
```

### Complex State Transitions

```
# Create a task
slow_cooker 30

# Start in background
startbg 1

# Suspend the background task
suspend 1

# Resume in foreground
fg 1

# Suspend again using Ctrl-Z
# Press Ctrl-Z

# Resume in background
bg 1

# Move to foreground
fg 1

# Kill using Ctrl-C
# Press Ctrl-C

# List to verify status
list
```

## Special Test Cases

### Rapid Command Sequence

```
# Create multiple tasks in quick succession
ls
cal
slow_cooker 5

# Execute rapid commands
start 1
list
kill 3
start 2
list
```

### Process Group Testing

```
# Create a task
slow_cooker 10

# Start in foreground
start 1

# Press Ctrl-C to terminate
# This should only affect the foreground task, not the shell

# Create another task
slow_cooker 5

# Start in foreground
start 2

# List tasks to verify the shell is still responsive
list
```

### Pipe Error Handling

```
# Create tasks for piping
cat nonexistent_file
grep pattern

# Attempt to pipe with an invalid first command
pipe 1 2

# Create valid tasks for piping
ls
grep pattern

# Pipe with valid commands
pipe 3 4
```

## Comprehensive Integration Tests

### Full Workflow Test

```
# Create multiple tasks of different types
ls -la
cat fox.txt
slow_cooker 5
sleep 10
grep the

# Execute tasks in different ways
startbg 3
start 1
start 2 > output.txt
pipe 2 5

# Test process control
suspend 3
fg 3
suspend 3
bg 3
kill 4

# Final status check
list
```

### Signal and State Test Sequence

```
# Create tasks
slow_cooker 20
slow_cooker 15
slow_cooker 10

# Start all tasks
startbg 1
startbg 2
startbg 3

# Suspend one task
suspend 2

# Cycle through different states
fg 2
# Press Ctrl-Z
bg 2
kill 3
fg 1
# Press Ctrl-\
list
```

## Integration with Test Scripts

You can add these test cases to the `hiy-shell-commands.md` file by:

1. Copying and pasting the relevant sections
2. Integrating these tests with the existing test structure
3. Adding explanatory comments about expected behavior

When conducting manual testing:

1. Use the structured approach from the original document
2. Supplement with these additional test cases
3. Document all test results thoroughly

Remember that these additional tests are designed to complement, not replace, the core test sequences from the Master Project Documentation. 