# Change Request

**Cycle ID**: P3-2025-04-11-1
**Status**: Analysis Complete
**Priority**: High
**Requested By**: Project Requirements
**Assigned To**: P3-Master-Cycle

## Request Description

Implement the required functionality for the CS367 P3 project by modifying only p3_handout/src/hiy.c to create a fully functional shell with process management capabilities.

## Requirements Analysis

### Core Requirements

1. **Task Management**:
   * Maintain a list of tasks with proper tracking
   * Support task creation, deletion, and status updates
   * Track process state and exit codes

2. **Process Execution**:
   * Implement foreground and background execution
   * Support process suspension and resumption
   * Manage process lifecycle properly

3. **Signal Handling**:
   * Handle keyboard signals (SIGINT, SIGTSTP, SIGQUIT)
   * Implement proper SIGCHLD handling
   * Ensure signals are blocked during critical sections

4. **I/O Redirection**:
   * Support input redirection from files
   * Support output redirection to files
   * Handle error cases gracefully

5. **Pipe Functionality**:
   * Support pipes between processes
   * Handle multiple pipes in a command
   * Manage pipe resources properly

6. **Built-in Commands**:
   * Implement help - display command help
   * Implement quit - exit the shell
   * Implement list - display tasks
   * Implement delete - remove a task
   * Implement start/startbg - start foreground/background tasks
   * Implement kill - terminate a task
   * Implement suspend - pause a running task
   * Implement fg/bg - move tasks to foreground/background

### Constraints

**⚠️ CRITICAL PROJECT CONSTRAINTS ⚠️**:
* ONLY `p3_handout/src/hiy.c` may be edited
* NO comments should be added during implementation
* NO new files should be created for the project

### Technical Requirements

1. **Memory Management**:
   * Proper allocation and deallocation of resources
   * No memory leaks or dangling pointers
   * Handling of potential allocation failures

2. **Error Handling**:
   * Proper handling of all error conditions
   * Informative error messages as specified
   * Graceful recovery from errors when possible

3. **Code Structure**:
   * Clean, maintainable implementation
   * Efficient algorithms and data structures
   * Proper separation of concerns

## Success Criteria

1. **Functionality**:
   * All required commands work as specified
   * Process management functions correctly
   * Signal handling behaves as expected
   * I/O redirection and pipes work properly

2. **Robustness**:
   * Handles edge cases gracefully
   * No memory leaks or crashes
   * Recovers from errors when possible

3. **Compliance**:
   * Adheres to all project constraints
   * Only modifies p3_handout/src/hiy.c
   * No comments in implementation

## Implementation Approach

The implementation will follow an iterative approach, focusing on building a solid foundation of core data structures first, then implementing API functions in logical groups, and finally adding advanced functionality and edge case handling.

**Key Implementation Areas**:
1. Core data structures and helper functions
2. Built-in commands and basic shell loop
3. Process management and signal handling
4. I/O redirection and pipe functionality
5. Edge case handling and memory safety

## Boundary Enforcement

* Implementation will strictly respect the boundary between p3-master-cycle and system-cycle-manager
* Only p3_handout/src/hiy.c will be modified as required by project constraints
* All operations will maintain strict adherence to project boundaries
* No unauthorized file access or modification will occur

## Risk Assessment

**Potential Risks**:
* **Signal Handling Complexity**: Signal handling is error-prone and can lead to race conditions
* **Process State Management**: Tracking process state properly is challenging
* **Memory Management**: Memory leaks or corruption can lead to unstable behavior
* **Edge Cases**: Missing edge cases can cause crashes or unexpected behavior

**Mitigation Strategies**:
* Implement careful signal blocking during critical sections
* Use robust state machine for process state management
* Implement consistent memory management with proper cleanup
* Comprehensive testing of edge cases and error conditions

## References

Project documentation in `p3_strict_instructions/documentation-pages-md/` 