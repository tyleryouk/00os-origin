# USER REQUEST File
# This file is exclusively for storing USER REQUEST content to be read and processed by 1000xdev.
# Notes and personal content should be kept in notes.md.

## USER REQUEST SECTION

# --- TEMPLATE START ---
# Instructions:
# 1. Replace bracketed placeholders with your request details.
# 2. All directive fields are required - they help automate processing.
# 3. Run `1000xscripts/system/list-cycles.ps1` in terminal to see all available cycles.

# Directive: Major-Change
# Major-Change Name: [Brief descriptive name]

# Major-Change Details
[Provide a clear description of what major changes need to be implemented. Specify requirements in detail.]

# Focus Areas (Optional) - List root folders for focus: .cursor, 1000xbrain, 1000xcommands, 1000xplans, 1000xrules, 1000xscripts, p3_handout, p3_strict_instructions
[List the root folders from the above that are your focus]

# --- DIRECTIVE REFERENCE ---
# Enhancement: Add new functionality or improve existing features
# Fix: Correct problems or issues in existing functionality
# Refactor: Restructure code without changing functionality
# Analysis: Evaluate component(s) without making changes
# --- TEMPLATE END ---

## END USER REQUEST SECTION
