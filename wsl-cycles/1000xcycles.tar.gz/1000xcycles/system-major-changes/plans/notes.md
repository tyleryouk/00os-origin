## 1000xnotes by Tyler Youk


## p3 notes

MAJOR CHANGES TO ENTIRE SYSTEM

You will now use "cycles" as the core of your development process. I made major system-wide changes to the structure of 1000xbrain and 1000xcycles (newly created). These will be the two core systems. I merged the root folders 1000xcommands, 1000xplans, 1000xscripts, and 1000xbrain/{domain}/{cycle-name}\operational-feedback to the one centralized folder 1000xcycles.


Please make at least 30 tool calls to fully understand the current structure of 1000xcycles, 1000xbrain and 1000xrules. 1000xcommands won't work anymore because the new path for all 1000xcommands is 1000xcycles/{cycle-name}/commands/{sequential-1000xcommands-1-to-7}. We need to update 1000xrules before we can update 1000xbrain and 1000xcycles to align with this new system. I have deleted the legacy 1000xcommands, 1000xscripts, and 1000xplans.


Previous root folder structure:
1000xbrain/
1000xcommands/
1000xplans/
1000xrules/
1000xscripts/
p3_handout/
p3_strict_instructions/

## **First Set of Tasks: Update 1000xrules**

1000xrules/core/ MUST first be updated to read the new structure of the 1000xsystem. The new 1000xcommands have the filepath:
1000xcycles/{cycle-name}/commands/{1000xcommand}

You will update the parsing process for `run command:domain/{command-name}`:

1.The new keyword which will trigger the read to the 1000xcommand will be: `run:{cycle-name}/{1000xcommand}`. You will remove any usage of the old key word `run command:`. The new keyword is simply `run:` which will always be lower case and have the colon after run. 

2. After the keyword is received, you need to make a tool call to read the 1000xcommand in full at the new location: `1000xcycles/{cycle-name}/commands/{1000xcommand}`

**Example of correct keyword syntax**
run:system-major-changes/1

After receiving this example keyword, you will make a tool call to read_file at filepath:
1000xcycles/system-major-changes/commands/1.md

3. Run internal tests to verify that the newly created instructions in 1000xrules is accurate (actually make the tool calls to read the 1000xcommand).

4. Read every file in 1000xrules to ensure alignment with the new 1000xsystems.


**Context on new 1000xsystem structure**
We came up with this new structure in a previous thread to simplify the run command process. The main difference in the new 1000xsystem structure is that *each cycle will work independently of eachother*. This will allow us to focus on one cycle at a time. There will only be 4 cycles for this project, which will allow us to focus on optimizing and enhancing 4 core cycles which will guide you through the entire development process. 

**Context on cycles**
#### p3-master-cycle
p3-master-cycle will be responsible for changes to p3_handout/src/hiy.c . p3-master-cycle will be the ONLY cycle that can edit p3_handout/src/hiy.c. This needs to be very clear. The other three cycles are focused on **workflow** enhancements. 1000xdev, you must be in p3-master-cycle to code and make changes to p3_handout/src/hiy.c. p3-master-cycle will log workflow errors and enhancements in 1000xcycles/system-cycle-manager/

#### system-autonomous
system-autonomous will be responsible for changes to 1000xbrain and 1000xcycles, focused on optimization and ensuring that the master-cycle efficiently utilizes the knowledge in 1000xbrain and utilizes its own cycle configurations efficiently. system-autonomous can edit anything within 1000xbrain, 1000xcycles, and 1000xrules to optimize workflows. system-autonomous is primarily focused on consolidation and optimization (subtraction, less clutter, **reduced cognitive load for workflow**).

#### system-major-changes
system-major-changes will be responsible for major changes throughout all folders, primarily focused on new features and enhancements (additions to 1000xsystem).

#### system-cycle-manager
cycle-manager will be responsible for any errors in the cycle process for master-cycle. cycle-manager


#### Goals of four core cycles
You will utilize p3-master-cycle to code. You will utilize the three system cycles to enhance your productivity and efficiently while in the cycle p3-master-cycle. The primary focus of the three system cycles is to **enhance workflow of master-cycle**.

1000xbrain is now the central hub for all knowledge and guidelines.
1000xcycles includes all of the necessary information for each process.
1000xcycles and 1000xbrain will need to work together. Nearly all filepaths within 1000xcycles and 1000xbrain are incorrect, which we will address in the next set of tasks. For this task, just focused on 1000xrules, which is automatically synced to Cursor Rules.
1000xbrain is your brain, 1000xcycles is the instructions for the 1000xworkflows that you have created for yourself. This allows you to abstract all neccessary information to 1000xcycles will keeping your brain sharp and focus on the task at hand. Think of it like this. You can look at 1000xcycles and choose to work on any cycle you like, because all instructions and configurations are within 1000xcycles. You can also move around between cycles because each cycle will work independently of eachother.

## **Second Task: Update script to sync 1000xrules to .cursor rules**

Next, the script in 1000xcycles/scripts/system/sync-rules.sh needs to be updated (likely a simple filepath change) to sync 1000xrules to .cursor rules.


## master-cycle enhancements
Move p3_strict_instructions to 1000xbrain/knowledge-base/ ?

Update tool calls in cycle-commands for p3-master-cycle

Update knowledge-base files for p3-master-cycle

Update process files for p3-master-cycle

Update cycle-manager internally to work better with p3-master-cycle.



Change names of cycles:
system-autonomous to system-optimization (focused on reducing clutter and reducing cognitive load for master-cycle workflow)
system-major-changes to system-enhancements (focused on adding new features to system)









