#!/bin/bash
# Syncs 1000xrules .md files to .cursor/rules .mdc files, preserving existing frontmatter.

# Parse command line arguments
DETECT_ORPHANS=false
REMOVE_ORPHANS=false
DRY_RUN=false

for arg in "$@"; do
  case $arg in
    -DetectOrphans)
      DETECT_ORPHANS=true
      ;;
    -RemoveOrphans)
      DETECT_ORPHANS=true
      REMOVE_ORPHANS=true
      ;;
    -DryRun)
      DRY_RUN=true
      ;;
    -h|--help)
      echo "Usage: sync-rules.sh [options]"
      echo "Options:"
      echo "  -DetectOrphans    Detect orphaned Cursor Rules (mdc files without md source)"
      echo "  -RemoveOrphans    Remove orphaned Cursor Rules (implies -DetectOrphans)"
      echo "  -DryRun           Report changes without making actual changes"
      echo "  -h, --help        Show this help message"
      exit 0
      ;;
  esac
done

# Define source and target directories
SOURCE_DIR="1000xrules"
TARGET_DIR=".cursor/rules"
REPORT_DIR="1000xcycles/system-major-changes/scripts/sync-reports"

# Create target and report directories if they don't exist
mkdir -p "$TARGET_DIR/core/communication"
mkdir -p "$TARGET_DIR/core/identity"
mkdir -p "$TARGET_DIR/core/tools"
mkdir -p "$REPORT_DIR"

# Initialize counters and arrays for reporting
TOTAL_FILES=0
UPDATED_FILES=0
CREATED_FILES=0
SKIPPED_FILES=0
ERROR_FILES=0
ORPHANED_FILES=0
REMOVED_ORPHANS=0

# Arrays to store file lists
UPDATED_FILES_LIST=()
CREATED_FILES_LIST=()
SKIPPED_FILES_LIST=()
ERROR_FILES_LIST=()
ORPHANED_FILES_LIST=()
REMOVED_ORPHANS_LIST=()
MATCHED_MDC_FILES=()

# Function to generate a simple hash (using cksum) of the file path for ruleId
generate_rule_id() {
    local filepath="$1"
    # Remove leading ./ if present
    filepath="${filepath#./}"
    echo $(echo -n "$filepath" | cksum | awk '{print $1}')
}

# Function to extract only the frontmatter from a file
get_frontmatter() {
    local file="$1"
    # Check if file has frontmatter
    if grep -q "^---$" "$file"; then
        # Extract the frontmatter block (including the --- markers)
        sed -n '1,/^---$/p' "$file" | sed -n '/^---$/,/^---$/p'
    else
        echo ""
    fi
}

# Function to get content without frontmatter
get_content_without_frontmatter() {
    local file="$1"
    # Count the number of --- lines in the file
    local dash_count=$(grep -c "^---$" "$file")
    
    if [ "$dash_count" -ge 2 ]; then
        # File has frontmatter
        # Extract content after the second --- marker
        sed -e '1,/^---$/d' -e '1,/^---$/d' "$file"
    else
        # No frontmatter, return all content
        cat "$file"
    fi
}

# Function to process a single file - returns a status code
# 0 = skipped, 1 = updated, 2 = created, 3 = error
process_file() {
    local source_file="$1"
    local source_dir="$2"
    local target_dir="$3"
    
    # Skip README.md files
    if [[ $(basename "$source_file") == "README.md" ]]; then
        echo "Skipping README.md file: $source_file"
        SKIPPED_FILES_LIST+=("Skipped README.md: ${source_file#$SOURCE_DIR/}")
        return 0 # Skipped
    fi
    
    # Extract relative path from source directory
    local rel_path="${source_file#$source_dir/}"
    local dir_path=$(dirname "$rel_path")
    local filename=$(basename "$source_file")
    local target_filename="${filename%.md}.mdc"
    local target_file="$target_dir/$dir_path/$target_filename"
    
    # Create target directory if it doesn't exist
    mkdir -p "$(dirname "$target_file")"
    
    echo "Processing: $rel_path"
    
    # Add to matched files list for orphan detection
    MATCHED_MDC_FILES+=("$target_file")
    
    # Get content without frontmatter from source
    local source_content=$(get_content_without_frontmatter "$source_file")
    
    # Check if target file exists
    if [[ -f "$target_file" ]]; then
        # Extract frontmatter from target file if it exists
        local target_frontmatter=$(get_frontmatter "$target_file")
        local target_content=$(get_content_without_frontmatter "$target_file")
        
        # Normalize line endings for comparison
        source_content=$(echo "$source_content" | tr -d '\r')
        target_content=$(echo "$target_content" | tr -d '\r')
        
        # Compare content and update if different
        if [[ "$source_content" != "$target_content" ]]; then
            if [[ "$DRY_RUN" == "false" ]]; then
                local temp_file="${target_file}.tmp"
                
                if [[ -n "$target_frontmatter" ]]; then
                    # Use existing frontmatter
                    echo "$target_frontmatter" > "$temp_file"
                    # Add a newline between frontmatter and content
                    echo "" >> "$temp_file"
                    # Add the source content
                    echo "$source_content" >> "$temp_file"
                    
                    # Move temp file to target
                    mv "$temp_file" "$target_file"
                    echo "  Updated (preserved frontmatter): $target_file"
                else
                    # Generate new frontmatter if none exists
                    local rule_id=$(generate_rule_id "$source_file")
                    
                    # Create file with frontmatter and content
                    echo "---" > "$temp_file"
                    echo "ruleId: $rule_id" >> "$temp_file"
                    echo "---" >> "$temp_file"
                    echo "" >> "$temp_file"
                    echo "$source_content" >> "$temp_file"
                    
                    # Move temp file to target
                    mv "$temp_file" "$target_file"
                    echo "  Updated (generated frontmatter): $target_file (RuleID: $rule_id)"
                fi
                
                UPDATED_FILES_LIST+=("Updated: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
                return 1 # Updated
            else
                echo "  Would update: $target_file (dry run)"
                UPDATED_FILES_LIST+=("Would update: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
                return 1 # Updated
            fi
        else
            echo "  No changes needed: $target_file"
            SKIPPED_FILES_LIST+=("No changes needed: ${source_file#$SOURCE_DIR/}")
            return 0 # Skipped
        fi
    else
        # Target file doesn't exist, create it
        if [[ "$DRY_RUN" == "false" ]]; then
            # Generate new frontmatter
            local rule_id=$(generate_rule_id "$source_file")
            local temp_file="${target_file}.tmp"
            
            # Create file with frontmatter and content
            echo "---" > "$temp_file"
            echo "ruleId: $rule_id" >> "$temp_file"
            echo "---" >> "$temp_file"
            echo "" >> "$temp_file"
            echo "$source_content" >> "$temp_file"
            
            # Move temp file to target
            mv "$temp_file" "$target_file"
            
            echo "  Created: $target_file (RuleID: $rule_id)"
            CREATED_FILES_LIST+=("Created: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
            return 2 # Created
        else
            echo "  Would create: $target_file (dry run)"
            CREATED_FILES_LIST+=("Would create: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
            return 2 # Created
        fi
    fi
    
    # This should not be reached
    return 3 # Error
}

# Function to process a directory and its subdirectories recursively
process_directory() {
    local source_dir="$1"
    local target_dir="$2"
    
    # Process files in current directory
    find "$source_dir" -maxdepth 1 -type f -name "*.md" | while read source_file; do
        process_file "$source_file" "$SOURCE_DIR" "$TARGET_DIR"
        # Update counters based on return code
        local status=$?
        TOTAL_FILES=$((TOTAL_FILES + 1))
        if [ $status -eq 0 ]; then
            SKIPPED_FILES=$((SKIPPED_FILES + 1))
        elif [ $status -eq 1 ]; then
            UPDATED_FILES=$((UPDATED_FILES + 1))
        elif [ $status -eq 2 ]; then
            CREATED_FILES=$((CREATED_FILES + 1))
        elif [ $status -eq 3 ]; then
            ERROR_FILES=$((ERROR_FILES + 1))
            ERROR_FILES_LIST+=("Error processing: ${source_file#$SOURCE_DIR/}")
        fi
    done
    
    # Process subdirectories recursively
    find "$source_dir" -mindepth 1 -maxdepth 1 -type d | while read subdir; do
        local subdir_name=$(basename "$subdir")
        process_directory "$subdir" "$target_dir/$subdir_name"
    done
}

# Create a temporary file to store counters
TEMP_COUNTERS=$(mktemp)

# Start processing from the root source directory
echo "Starting synchronization from $SOURCE_DIR to $TARGET_DIR..."

# Process the directory and use a temporary file to store results
{
    # Initialize counts in the subshell
    declare -i _TOTAL_FILES=0
    declare -i _UPDATED_FILES=0
    declare -i _CREATED_FILES=0
    declare -i _SKIPPED_FILES=0
    declare -i _ERROR_FILES=0
    
    # Find all .md files in the source directory (excluding README.md files)
    while read -r source_file; do
        # Skip README.md files
        if [[ $(basename "$source_file") == "README.md" ]]; then
            echo "Skipping README.md file: $source_file"
            SKIPPED_FILES_LIST+=("Skipped README.md: ${source_file#$SOURCE_DIR/}")
            _SKIPPED_FILES=$((_SKIPPED_FILES + 1))
            continue
        fi
        
        _TOTAL_FILES=$((_TOTAL_FILES + 1))
        
        # Extract relative path from source directory
        rel_path="${source_file#$SOURCE_DIR/}"
        dir_path=$(dirname "$rel_path")
        filename=$(basename "$source_file")
        target_filename="${filename%.md}.mdc"
        target_file="$TARGET_DIR/$dir_path/$target_filename"
        
        # Create target directory if it doesn't exist
        mkdir -p "$(dirname "$target_file")"
        
        echo "Processing: $rel_path"
        
        # Add to matched files list for orphan detection
        MATCHED_MDC_FILES+=("$target_file")
        
        # Get content without frontmatter from source
        source_content=$(get_content_without_frontmatter "$source_file")
        
        # Check if target file exists
        if [[ -f "$target_file" ]]; then
            # Extract frontmatter from target file if it exists
            target_frontmatter=$(get_frontmatter "$target_file")
            target_content=$(get_content_without_frontmatter "$target_file")
            
            # Normalize line endings for comparison
            source_content=$(echo "$source_content" | tr -d '\r')
            target_content=$(echo "$target_content" | tr -d '\r')
            
            # Compare content and update if different
            if [[ "$source_content" != "$target_content" ]]; then
                if [[ "$DRY_RUN" == "false" ]]; then
                    temp_file="${target_file}.tmp"
                    
                    if [[ -n "$target_frontmatter" ]]; then
                        # Use existing frontmatter
                        echo "$target_frontmatter" > "$temp_file"
                        # Add a newline between frontmatter and content
                        echo "" >> "$temp_file"
                        # Add the source content
                        echo "$source_content" >> "$temp_file"
                        
                        # Move temp file to target
                        mv "$temp_file" "$target_file"
                        echo "  Updated (preserved frontmatter): $target_file"
                    else
                        # Generate new frontmatter if none exists
                        rule_id=$(generate_rule_id "$source_file")
                        
                        # Create file with frontmatter and content
                        echo "---" > "$temp_file"
                        echo "ruleId: $rule_id" >> "$temp_file"
                        echo "---" >> "$temp_file"
                        echo "" >> "$temp_file"
                        echo "$source_content" >> "$temp_file"
                        
                        # Move temp file to target
                        mv "$temp_file" "$target_file"
                        echo "  Updated (generated frontmatter): $target_file (RuleID: $rule_id)"
                    fi
                    
                    UPDATED_FILES_LIST+=("Updated: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
                    _UPDATED_FILES=$((_UPDATED_FILES + 1))
                else
                    echo "  Would update: $target_file (dry run)"
                    UPDATED_FILES_LIST+=("Would update: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
                    _UPDATED_FILES=$((_UPDATED_FILES + 1))
                fi
            else
                echo "  No changes needed: $target_file"
                SKIPPED_FILES_LIST+=("No changes needed: ${source_file#$SOURCE_DIR/}")
                _SKIPPED_FILES=$((_SKIPPED_FILES + 1))
            fi
        else
            # Target file doesn't exist, create it
            if [[ "$DRY_RUN" == "false" ]]; then
                # Generate new frontmatter
                rule_id=$(generate_rule_id "$source_file")
                temp_file="${target_file}.tmp"
                
                # Create file with frontmatter and content
                echo "---" > "$temp_file"
                echo "ruleId: $rule_id" >> "$temp_file"
                echo "---" >> "$temp_file"
                echo "" >> "$temp_file"
                echo "$source_content" >> "$temp_file"
                
                # Move temp file to target
                mv "$temp_file" "$target_file"
                
                echo "  Created: $target_file (RuleID: $rule_id)"
                CREATED_FILES_LIST+=("Created: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
                _CREATED_FILES=$((_CREATED_FILES + 1))
            else
                echo "  Would create: $target_file (dry run)"
                CREATED_FILES_LIST+=("Would create: ${source_file#$SOURCE_DIR/} -> ${target_file#$TARGET_DIR/}")
                _CREATED_FILES=$((_CREATED_FILES + 1))
            fi
        fi
    done < <(find "$SOURCE_DIR" -type f -name "*.md" -not -name "README.md")
    
    # Save the counts to the temporary file
    echo "$_TOTAL_FILES $_UPDATED_FILES $_CREATED_FILES $_SKIPPED_FILES $_ERROR_FILES" > "$TEMP_COUNTERS"
}

# Read the counts from the temporary file
read TOTAL_FILES UPDATED_FILES CREATED_FILES SKIPPED_FILES ERROR_FILES < "$TEMP_COUNTERS"
rm "$TEMP_COUNTERS"

# Handle orphaned files if requested
if [[ "$DETECT_ORPHANS" == "true" ]]; then
    echo ""
    echo "Checking for orphaned Cursor Rules files..."
    
    # Find all .mdc files in target directory
    readarray -t all_mdc_files < <(find "$TARGET_DIR" -type f -name "*.mdc")
    
    # Find orphaned .mdc files (those without corresponding .md files)
    for mdc_file in "${all_mdc_files[@]}"; do
        is_matched=false
        for matched_file in "${MATCHED_MDC_FILES[@]}"; do
            if [[ "$mdc_file" == "$matched_file" ]]; then
                is_matched=true
                break
            fi
        done
        
        if [[ "$is_matched" == "false" ]]; then
            ORPHANED_FILES=$((ORPHANED_FILES + 1))
            ORPHANED_FILES_LIST+=("$mdc_file")
            
            echo "  Orphaned: $mdc_file"
            
            # Remove orphaned files if requested
            if [[ "$REMOVE_ORPHANS" == "true" ]]; then
                if [[ "$DRY_RUN" == "false" ]]; then
                    rm "$mdc_file"
                    echo "    Removed orphaned file: $mdc_file"
                    REMOVED_ORPHANS=$((REMOVED_ORPHANS + 1))
                    REMOVED_ORPHANS_LIST+=("$mdc_file")
                else
                    echo "    Would remove orphaned file: $mdc_file (dry run)"
                    REMOVED_ORPHANS=$((REMOVED_ORPHANS + 1))
                    REMOVED_ORPHANS_LIST+=("$mdc_file")
                fi
            fi
        fi
    done
    
    if [[ "$ORPHANED_FILES" -eq 0 ]]; then
        echo "  No orphaned mdc files found."
    elif [[ "$REMOVE_ORPHANS" == "false" ]]; then
        echo "  Orphaned files detection only. Use -RemoveOrphans to remove these files."
    fi
fi

# Generate report
TIMESTAMP=$(date +"%Y-%m-%d-%H%M%S")
REPORT_FILE="$REPORT_DIR/sync-results-$TIMESTAMP.md"

# Create report content
cat > "$REPORT_FILE" << EOF
# Cursor Rules Synchronization Report

Generated: $(date +"%Y-%m-%d %H:%M:%S")

## Summary
- Mode: $(if [[ "$DRY_RUN" == "true" ]]; then echo "Dry Run (no changes made)"; else echo "Live Run (changes applied)"; fi)
- Total files processed: $TOTAL_FILES
- Files updated: $UPDATED_FILES
- Files created: $CREATED_FILES
- Files skipped: $SKIPPED_FILES
- Errors: $ERROR_FILES
$(if [[ "$DETECT_ORPHANS" == "true" ]]; then echo "- Orphaned files detected: $ORPHANED_FILES"; fi)
$(if [[ "$REMOVE_ORPHANS" == "true" ]]; then echo "- Orphaned files removed: $REMOVED_ORPHANS"; fi)

## Details

### Updated Files
$(if [[ ${#UPDATED_FILES_LIST[@]} -gt 0 ]]; then printf "%s\n" "${UPDATED_FILES_LIST[@]}"; else echo "None"; fi)

### Created Files
$(if [[ ${#CREATED_FILES_LIST[@]} -gt 0 ]]; then printf "%s\n" "${CREATED_FILES_LIST[@]}"; else echo "None"; fi)

### Skipped Files
$(if [[ ${#SKIPPED_FILES_LIST[@]} -gt 0 ]]; then printf "%s\n" "${SKIPPED_FILES_LIST[@]}"; else echo "None"; fi)

### Errors
$(if [[ ${#ERROR_FILES_LIST[@]} -gt 0 ]]; then printf "%s\n" "${ERROR_FILES_LIST[@]}"; else echo "None"; fi)

$(if [[ "$DETECT_ORPHANS" == "true" ]]; then
echo "### Orphaned Files"
if [[ ${#ORPHANED_FILES_LIST[@]} -gt 0 ]]; then 
    for file in "${ORPHANED_FILES_LIST[@]}"; do
        echo "- $file"
    done
else 
    echo "None"
fi

if [[ "$REMOVE_ORPHANS" == "true" ]]; then
echo "### Removed Orphaned Files"
if [[ ${#REMOVED_ORPHANS_LIST[@]} -gt 0 ]]; then 
    for file in "${REMOVED_ORPHANS_LIST[@]}"; do
        echo "- $file"
    done
else 
    echo "None"
fi
fi
fi)

## Important Notes

- README.md files are explicitly excluded from synchronization
- Frontmatter in .mdc files is always preserved during synchronization
- Rule types must be managed through the Cursor UI
EOF

# Clean up old reports (keep only the 5 most recent)
if [[ -d "$REPORT_DIR" ]]; then
    find "$REPORT_DIR" -name "sync-results-*.md" | sort -r | tail -n +6 | xargs -r rm
    echo "Cleaned up old reports (keeping the 5 most recent)"
fi

# Print summary to console
echo ""
echo "Synchronization Complete!"
echo "=========================="
echo "Total files processed: $TOTAL_FILES"
echo "Files updated: $UPDATED_FILES"
echo "Files created: $CREATED_FILES"
echo "Files skipped: $SKIPPED_FILES"
echo "Errors: $ERROR_FILES"

if [[ "$DETECT_ORPHANS" == "true" ]]; then
    echo "Orphaned files detected: $ORPHANED_FILES"
    
    if [[ "$REMOVE_ORPHANS" == "true" ]]; then
        echo "Orphaned files removed: $REMOVED_ORPHANS"
    fi
fi

echo ""
echo "Report saved to: $REPORT_FILE"
echo "Sync complete: $SOURCE_DIR -> $TARGET_DIR" 