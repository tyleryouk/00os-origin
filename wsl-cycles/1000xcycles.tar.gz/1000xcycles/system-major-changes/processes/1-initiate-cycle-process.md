# Process: Initiate Cycle

# Defines the steps for initiating a new major-changes cycle.

## Goal: Initialize a new cycle for implementing system-wide changes across all 1000xsystems.

## Steps:

1.  **Check Operational Feedback Directory**:
    *   Use `list_dir` to check `1000xcycles/system-major-changes/operational_feedback/`.
    *   **(Error Handling)**: If directory doesn't exist, create it using terminal command.

2.  **Create/Update User Request Template**:
    *   Use `edit_file` to completely overwrite `1000xcycles/system-major-changes/plans/user_request.md`:
        ```markdown
        # USER REQUEST File
        # This file is exclusively for storing USER REQUEST content to be read and processed by 1000xdev.
        # Notes and personal content should be kept in notes.md.

        ## USER REQUEST SECTION

        # --- TEMPLATE START ---
        # Instructions:
        # 1. Replace bracketed placeholders with your request details.
        # 2. All directive fields are required - they help automate processing.
        # 3. Run `1000xscripts/system/list-cycles.ps1` in terminal to see all available cycles.

        # Directive: Major-Change
        # Major-Change Name: [Brief descriptive name]

        # Major-Change Details
        [Provide a clear description of what major changes need to be implemented. Specify requirements in detail.]

        # Focus Areas (Optional) - List root folders for focus: .cursor, 1000xbrain, 1000xcommands, 1000xplans, 1000xrules, 1000xscripts, p3_handout, p3_strict_instructions
        [List the root folders from the above that are your focus]

        # --- DIRECTIVE REFERENCE ---
        # Enhancement: Add new functionality or improve existing features
        # Fix: Correct problems or issues in existing functionality
        # Refactor: Restructure code without changing functionality
        # Analysis: Evaluate component(s) without making changes
        # --- TEMPLATE END ---

        ## END USER REQUEST SECTION
        ```
    *   **IMPORTANT**: Do NOT preserve previous requests in user_request.md - it should be completely overwritten
    *   **(Error Handling)**: If template creation fails, provide clear error message.

3.  **Create or Update Cycle Log**:
    *   Use `read_file` to check if `1000xcycles/system-major-changes/operational_feedback/current_cycle.md` exists.
    *   If it exists, read it to check the status of any existing cycle.
    *   If it doesn't exist or shows a completed cycle, create a new cycle log.
    *   Use `edit_file` to update with new cycle information:
        ```
        # Current Cycle
        
        **Cycle ID**: MC-[timestamp]
        **Status**: Initialized
        **Operation Mode**: Unspecified
        
        ## Current Phase
        
        Initialization completed. Waiting for requirement analysis.
        
        ## Document References
        
        * User Request: 1000xcycles/system-major-changes/plans/user_request.md
        * Change Request: 1000xcycles/system-major-changes/operational_feedback/change_request.md
        
        ## Next Steps
        
        Fill out the USER REQUEST SECTION in 1000xcycles/system-major-changes/plans/user_request.md and then invoke `run:system-major-changes/2`
        ```

4.  **Create Empty Change Request Document**:
    *   Create `1000xcycles/system-major-changes/operational_feedback/change_request.md`
    *   Use `edit_file` to initialize with structure:
        ```
        # Change Request Details
        
        **Requestor**: Tyler Youk
        **Status**: Awaiting User Input
        **Directive**: Unspecified
        **Target Cycle**: system/major-changes
        **Enhancement Name**: Unspecified
        **Priority**: Unspecified
        
        ## Request Description
        
        *Waiting for user to fill out request in 1000xcycles/system-major-changes/plans/user_request.md*
        
        ## Requirements
        
        *To be determined after user provides request details*
        
        ## Scope
        
        *To be determined after user provides request details*
        
        ## Success Criteria
        
        *To be determined after user provides request details*
        ```

5.  **Check Cycle System Guidelines**:
    *   Verify alignment with `1000xbrain/guidelines/cycle-management/cycle-system-guidelines.md`.
    *   Ensure this process follows the guideline to completely overwrite user_request.md.

6.  **Signal Completion**:
    *   Completion is implicitly signaled by updating the status files in the previous steps.
    *   No explicit terminal command should be used for signaling completion.
    *   The user should:
        *   Fill out the USER REQUEST SECTION in `1000xcycles/system-major-changes/plans/user_request.md`
        *   Run `run:system-major-changes/2` after completing the request details.

## Special Considerations

1. **User Request Handling**:
   * ALWAYS completely overwrite user_request.md rather than preserving previous requests
   * This keeps the user_request.md file concise and focused on the current request only
   * Previous requests should be archived elsewhere if needed

2. **Sequential Cycle Pattern**:
   * Follow the standard sequential step pattern (1, 2, 3, etc.)
   * Ensure clear state transitions between steps
   * Maintain proper operational feedback structure 