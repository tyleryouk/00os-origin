# Process: Refinement

# Defines the steps for refining cycle implementations to address verification issues.
# Follows guidelines in: 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/6-refinement-process-guidelines.md

## Goal: Address issues identified during verification to ensure cycles meet all requirements and standards.

## Steps:

1.  **Read Guidelines**
    - 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/3-planning-process-guidelines.md
    - 1000xbrain/guidelines/cycle-management/cycle-patterns.md
    - 1000xbrain/guidelines/planning/implementation-planning.md
    ```
    *   **(Boundary Enforcement)**: Verify all documentation files exist and contain required content
    *   **(Error Handling)**: If any documentation file is missing or incomplete, log the issue and continue with available information

2.  **Check Cycle Status and Analyze Verification Report**:
    *   Verify cycle status and analyze verification report in a consolidated operation:
    ```
    # Read cycle status and verification report in a single logical group
    read_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/verification_report.md", should_read_entire_file=true)
    ```
    *   Process gathered information:
        - Verify that verification has been completed and identified issues
        - Extract the issues requiring refinement
        - Prioritize issues based on severity and dependencies
    *   **(Boundary Enforcement)**: Validate verification completion and issue identification
    *   **(Error Handling)**: If verification hasn't been completed or no issues were found, log status and suggest appropriate next step

3.  **Group Issues and Develop Refinement Plan**:
    *   Categorize issues and develop a comprehensive refinement plan:
        - Structure Issues (missing files, incorrect structure)
        - Content Issues (incorrect format, missing sections)
        - Functional Issues (requirements not met)
        - Unified Model Issues (mode handling, enhancement documentation)
        - Documentation Issues (incomplete, unclear documentation)
    *   Identify common patterns or root causes
    *   Determine refinement approach for each category
    *   **(Boundary Enforcement)**: Ensure issue categorization is complete and accurate
    *   **(Error Handling)**: If planning cannot proceed, document challenges and request clarification

4.  **Address Structure and Content Issues**:
    *   Fix issues with directory structure, missing files, and file content in a systematic approach:
        - Create missing command files
        - Create missing process files
        - Create missing knowledge files
        - Update command files to follow correct format
        - Enhance process files with missing sections
        - Improve knowledge file organization
    *   **(Boundary Enforcement)**: Verify file creation and modification follows standards
    *   **(Error Handling)**: Handle each file independently to prevent cascading failures

5.  **Address Functional and Unified Model Issues**:
    *   Fix issues with functionality and unified model implementation:
        - Implement missing requirements
        - Correct implementation errors
        - Enhance existing implementations
        - Improve handling of both operation modes
        - Ensure seamless mode transitions
    *   **(Boundary Enforcement)**: Verify functional implementations meet requirements
    *   **(Error Handling)**: If implementation is complex, break down into smaller steps

6.  **Create Refinement Log**:
    *   Document all refinement actions and their outcomes:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/refinement_log.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create refinement log
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/refinement_log.md", "Create refinement log", 
    """
    # Refinement Log

    **Date**: [current-date]
    **Verification Report**: [reference to verification_report.md]

    ## Refinement Actions

    ### Structure Refinements

    1. **[Issue Description]**:
       * Action Taken: [Description of refinement]
       * Files Modified: [List of files]
       * Status: [Resolved/Partially Resolved]
       * Notes: [Any relevant notes]

    ### Content Refinements

    1. **[Issue Description]**:
       * Action Taken: [Description of refinement]
       * Files Modified: [List of files]
       * Status: [Resolved/Partially Resolved]
       * Notes: [Any relevant notes]

    ### Functional Refinements

    1. **[Issue Description]**:
       * Action Taken: [Description of refinement]
       * Files Modified: [List of files]
       * Status: [Resolved/Partially Resolved]
       * Notes: [Any relevant notes]

    ### Unified Model Refinements

    1. **[Issue Description]**:
       * Action Taken: [Description of refinement]
       * Files Modified: [List of files]
       * Status: [Resolved/Partially Resolved]
       * Notes: [Any relevant notes]

    ### Documentation Refinements

    1. **[Issue Description]**:
       * Action Taken: [Description of refinement]
       * Files Modified: [List of files]
       * Status: [Resolved/Partially Resolved]
       * Notes: [Any relevant notes]

    ## Remaining Issues

    * **[Issue 1]**: [Reason unresolved and recommendation]
    * **[Issue 2]**: [Reason unresolved and recommendation]

    ## Overall Refinement Status

    [SUCCESSFUL/PARTIALLY SUCCESSFUL]: [Summary of refinement results]

    ## Next Steps

    [Recommendation for re-verification or completion]
    """)
    ```
    *   **(Boundary Enforcement)**: Verify refinement log contains all required sections
    *   **(Error Handling)**: If log creation fails, retry with simplified format

7.  **Update Cycle Status and Signal Completion**:
    *   Update cycle status and signal completion in a consolidated operation:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update cycle status
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update status to refinement complete", 
    """
    # Current Cycle Status

    **Cycle ID**: [extracted_cycle_id]
    **Status**: Refinement Completed
    **Operation Mode**: [current_operation_mode]
    **Selected Option**: [selected_option]
    **Current Phase**: Refinement Complete

    // ... existing progress summary ...

    ## Recent Logs

    **[timestamp] Refinement**: [refinement_summary]
    
    // ... existing logs ...
    """)
    ```
    *   Indicate that refinement is complete with:
        - Summary of refinement results
        - Recommendation for next step (re-verification or completion)
        - If all issues were addressed, recommend `run:system-cycle-manager/5`
        - If some issues could not be resolved, recommend `run:system-cycle-manager/7`
    *   **(Boundary Enforcement)**: Verify status update contains all required information
    *   **(Error Handling)**: If status update fails, retry with simplified update

## Refinement Strategies

### Structure Refinement

* Focus on creating missing files
    # Boundary Check (Conceptual): 
    # Verify target_file (when creating files) is within allowed directories.
* Ensure proper directory structure
* Follow standard templates
* Verify file naming conventions

### Content Refinement

* Update file content to follow standard formats
    # Boundary Check (Conceptual): 
    # Verify target_file (when updating content) is within allowed directories.
* Add missing sections
* Improve organization
* Enhance clarity

### Functional Refinement

* Implement missing requirements
    # Boundary Check (Conceptual): 
    # Verify target_file (when implementing) is within allowed directories.
* Fix implementation errors
* Enhance existing implementations
* Test functionality after refinement

### Unified Model Refinement

* Ensure proper mode detection
* Verify handling of both operation modes
* Enhance enhancement documentation
    # Boundary Check (Conceptual): 
    # Verify target_file (when enhancing documentation) is within allowed directories.
* Fix any mode-specific issues

### Documentation Refinement

* Improve documentation clarity
* Add missing information
* Fix documentation errors
* Ensure documentation is up-to-date
    # Boundary Check (Conceptual): 
    # Verify target_file (when fixing documentation) is within allowed directories.

## Special Considerations

1. **Prioritization**:
   * Address critical issues first
   * Focus on issues that affect usability
   * Consider dependencies between issues

2. **Incremental Refinement**:
   * Refine in small, manageable steps
   * Test each refinement before proceeding
   * Document progress throughout

3. **Standards Alignment**:
   * Ensure all refinements maintain standards compliance
   * Consider whether standards need updating

4. **Feedback Loop**:
   * If refinement is extensive, consider re-verification
   * For minor refinements, proceed to completion

## Boundary Enforcement

1. **Input Validation**:
   * Verify verification has been completed
   * Validate verification report format and content
   * Check that issues are properly documented
   * Ensure cycle is in correct state for refinement

2. **Output Validation**:
   * Verify refinement log contains all required sections
   * Ensure cycle status is properly updated
   * Validate all refinements address identified issues
   * Check that next steps are clearly specified

3. **Error Recovery**:
   * Document unresolved issues with clear reasoning
   * Use partial refinements when complete resolution is not possible
   * Maintain system stability throughout refinement
   * Ensure proper handoff to next process 