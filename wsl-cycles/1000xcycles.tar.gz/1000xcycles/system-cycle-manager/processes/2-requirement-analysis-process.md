# Process: Requirement Analysis

## Goal: Analyze the selected option and determine the appropriate approach for the cycle.

## Steps:

1.  **Read Guidelines**:
    **Read process guidelines**
    - 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/2-requirement-analysis-process-guidelines.md
    - 1000xbrain/guidelines/cycle-management/cycle-patterns.md
    - 1000xbrain/guidelines/cycle-management/menu-options.md
    ```
    *   **(Boundary Enforcement)**: Verify all documentation files exist and contain required content
    *   **(Error Handling)**: If any documentation file is missing or incomplete, log the issue and continue with available information

2.  **Check Cycle Status and Read User Request**:
    *   Verify cycle status and read user request in a consolidated operation:
    ```
    # Read cycle status and user request in a single logical group
    read_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/plans/user_request.md", should_read_entire_file=true)
    ```
    *   Process gathered information:
        - Verify that the cycle is initialized
        - Parse the user request content
        - Look for an uncommented option selection
    *   **(Boundary Enforcement)**: Validate cycle status and user request format
    *   **(Error Handling)**: If cycle is not initialized or user request is invalid, log error and suggest appropriate action

3.  **Detect Selected Option and Set Operation Mode**:
    *   Parse the user request content to determine:
        - Selected option (OPTION 1, 2, 3, or 4)
        - Operation mode (AUTONOMOUS_MODE or USER_DIRECTED_MODE)
    *   If no option is explicitly selected, default to OPTION 3
    *   Set operation mode based on the selected option:
        - For OPTION 1, 2, and 4, set to AUTONOMOUS_MODE
        - For OPTION 3, check for explicit mode selection, defaulting to USER_DIRECTED_MODE if none specified
    *   Update current_cycle.md with the determined mode and selected option:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update cycle status with mode and selected option
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update mode and selected option", 
    """
# Current Cycle Status

**Cycle ID**: [extracted_cycle_id]
**Status**: Requirement Analysis
**Operation Mode**: [determined_operation_mode]
**Selected Option**: [selected_option]

    // ... existing code ...
    """)
    ```
    *   **(Boundary Enforcement)**: Validate option selection and mode setting
    *   **(Error Handling)**: If option detection fails, log error and use defaults

4.  **Process Option-Specific Information**:
    *   Based on the selected option, gather relevant information in a consolidated operation:
    ```
    # OPTION 1: p3-master-cycle notifications
    if (selected_option == "OPTION 1") {
        list_dir("1000xcycles/p3-master-cycle/operational_feedback/notifications/")
        # Guideline reference only: 1000xbrain/guidelines/cycle-management/centralized-error-handling.md
    }
    # OPTION 2: system-cycle-manager errors
    else if (selected_option == "OPTION 2") {
        list_dir("1000xcycles/system-cycle-manager/operational_feedback/system_errors/")
        # Guideline reference only: 1000xbrain/guidelines/cycle-management/system-error-tracking.md
    }
    # OPTION 3: user-directed request
    else if (selected_option == "OPTION 3") {
        # Guideline reference only: 1000xbrain/guidelines/cycle-management/cycle-patterns.md
    }
    # OPTION 4: autonomous mode
    else if (selected_option == "OPTION 4") {
        # Guideline reference only: 1000xbrain/guidelines/cycle-management/autonomous-enhancement.md
        read_file("1000xcycles/system-cycle-manager/operational_feedback/potential_enhancements.md", should_read_entire_file=true)
        read_file("1000xcycles/p3-master-cycle/operational_feedback/potential_enhancements.md", should_read_entire_file=true)
    }
    ```
    *   Process gathered information based on selected option
    *   **(Boundary Enforcement)**: Validate information gathering based on selected option
    *   **(Error Handling)**: If option-specific processing fails, log error and continue with base functionality

5.  **Create Option-Specific Change Request**:
    *   Create comprehensive change request based on selected option and gathered information:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/change_request.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create change request
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/change_request.md", "Create change request based on selected option", 
    """
# Change Request Details

**Requestor**: [appropriate_requestor]
**Status**: Analysis Completed
**Directive**: [appropriate_directive]
**Target Cycle**: [appropriate_target]
**Enhancement Name**: [appropriate_name]
**Priority**: [appropriate_priority]
**Operation Mode**: [determined_operation_mode]
**Selected Option**: [selected_option]

## Request Description

[option_specific_description]

## Requirements

[option_specific_requirements]

## Scope

[option_specific_scope]

## Success Criteria

[option_specific_criteria]

## Special Considerations

[option_specific_considerations]
""")
    ```
    *   **(Boundary Enforcement)**: Validate change request contains all required sections
    *   **(Error Handling)**: If change request creation fails, retry with simplified format

6.  **Update Cycle Status**:
    *   Update cycle status with requirement analysis completion:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update cycle status
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update status to requirement analysis complete", 
    """
# Current Cycle Status

**Cycle ID**: [extracted_cycle_id]
**Status**: Requirement Analysis Completed
**Operation Mode**: [determined_operation_mode]
**Selected Option**: [selected_option]
**Current Phase**: Planning

    // ... existing progress summary ...

## Recent Logs

**[timestamp] Requirement Analysis**: [analysis_summary_based_on_option]

    // ... existing logs ...
    """)
    ```
    *   **(Boundary Enforcement)**: Verify status update contains all required information
    *   **(Error Handling)**: If status update fails, retry with simplified update

7.  **Signal Completion**:
    *   Indicate that requirement analysis is complete with:
        - Summary of the selected option and its focus
        - Option-specific details (number of notifications, system errors, etc.)
        - Note that the next step is `run:system-cycle-manager/3`
    *   **(Boundary Enforcement)**: Verify completion signaling is clear and accurate
    *   **(Error Handling)**: If signaling is unclear, provide alternative instructions

## Special Considerations

1. **Option Processing Priority**:
   * Process the selected option with full focus
   * For OPTION 1, 2, and 4, operate in AUTONOMOUS_MODE
   * For OPTION 3, follow standard requirement analysis process
   * Document the selected option in all operational feedback files

2. **Notification Resolution (OPTION 1)**:
   * Read ALL notifications before taking action
   * Categorize and prioritize notifications by type and severity
   * Delete notifications ONLY after successful resolution
   * Create comprehensive resolution summary in resolution-complete.md

3. **Error Resolution (OPTION 2)**:
   * Read ALL system errors before taking action
   * Prioritize errors based on severity and impact
   * Delete error files ONLY after successful resolution
   * Document resolution approach and implementation in potential_enhancements.md

4. **User Request Processing (OPTION 3)**:
   * Follow standard requirement analysis process
   * Use user-provided details for enhancement requirements
   * Document all requirements and scope clearly in change request

5. **Autonomous Enhancement Selection (OPTION 4)**:
   * Select enhancement based on priority, complexity, and dependencies
   * Prioritize enhancing high-value systems (p3-master-cycle over system-cycle-manager)
   * Document selection rationale
   * Create comprehensive implementation plan

## Boundary Enforcement

1. **Input Validation**:
   * Verify cycle is properly initialized
   * Validate user request format and option selection
   * Check for required information based on selected option
   * Ensure necessary file structure exists for option processing

2. **Output Validation**:
   * Verify change request contains all required sections
   * Ensure cycle status is properly updated
   * Validate completion signal is clear and accurate
   * Check that all required operational feedback files are updated

3. **Error Recovery**:
   * Use default values for missing information
   * Proceed with simplified processing if full analysis fails
   * Document any issues in cycle logs
   * Ensure system remains in a consistent state 