# Process: Completion

# Defines the steps for completing a cycle and documenting results.
# Follows guidelines in: 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/7-completion-process-guidelines.md

## Goal: Finalize the cycle, document results, update potential future enhancements, and prepare for autonomous transition to the next cycle.

## Steps:

1.  **Read Guidelines**
    - 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/3-planning-process-guidelines.md
    - 1000xbrain/guidelines/cycle-management/cycle-patterns.md
    - 1000xbrain/guidelines/planning/implementation-planning.md
    ```
    *   **(Boundary Enforcement)**: Verify all documentation files exist and contain required content
    *   **(Error Handling)**: If any documentation file is missing or incomplete, log the issue and continue with available information

2.  **Check Cycle Status and Review Implementation Results**:
    *   Verify cycle status and review implementation results in a consolidated operation:
    ```
    # Read cycle status and implementation results in a single logical group
    read_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/change_request.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_log.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/verification_report.md", should_read_entire_file=true)
    ```
    *   Process gathered information:
        - Verify that implementation and verification have been completed
        - Check for operation mode (AUTONOMOUS_MODE or USER_DIRECTED_MODE)
        - Extract key information about what was implemented
        - Look for "System Error Resolution" section to identify any system errors being addressed
    *   **(Boundary Enforcement)**: Validate cycle completion status
    *   **(Error Handling)**: If verification is not complete, log error and suggest running verification first

3.  **Process System Errors (if applicable)**:
    *   If system errors were being addressed, check and update their status:
    ```
    # Get list of system errors
    list_dir("1000xcycles/system-cycle-manager/operational_feedback/system_errors/")
    
    # For each related system error being addressed:
    # Read error file and update if successfully resolved
    # Example for a specific error:
    read_file("1000xcycles/system-cycle-manager/operational_feedback/system_errors/[error-file].md", should_read_entire_file=true)
    
    # If verification confirmed successful resolution:
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/system_errors/[error-file].md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/system_errors/[error-file].md", "Update error status to resolved", 
    """
    # Update relevant sections only
    **Status**: Resolved
    
    ## Resolution Notes
    
    * **Resolved By**: [Current cycle ID]
    * **Resolution Date**: [Current date]
    * **Resolution Details**: [How the error was resolved]
    """)
    ```
    *   **(Boundary Enforcement)**: Verify error status updates are correctly formatted
    *   **(Error Handling)**: If error update fails, log warning but continue

4.  **Create Completion Summary and Update Potential Enhancements**:
    *   Document completion and update potential enhancements in a consolidated operation:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/completion_summary.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create completion summary
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/completion_summary.md", "Create completion summary", 
    """
    # Completion Summary

    **Cycle ID**: [from current_cycle.md]
    **Status**: Completed
    **Operation Mode**: [AUTONOMOUS_MODE or USER_DIRECTED_MODE]

    ## Implementation Summary

    [Brief summary of what was implemented]

    ## Results

    [Key outcomes and achievements]

    ## Challenges

    [Challenges encountered and how they were addressed]

    ## System Error Resolution (if applicable)

    **Errors Addressed**: [List of error IDs addressed]
    **Resolution Status**: [Resolved/Partially Resolved]
    **Resolution Notes**: [Details about how errors were resolved]

    ## Future Enhancements

    [Potential enhancements for future cycles]

    ## Next Steps

    [Suggestions for subsequent cycles]
    
    ## State Preservation

    **Completed Enhancement**: [Enhancement name]
    **Enhancement Status**: Completed
    **Progress Metrics**: [Relevant metrics]
    **Known Issues**: [Any outstanding issues]
    **Context Information**: [Important context for next cycle]
    """)
    
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/potential_enhancements.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update potential enhancements
    read_file("1000xcycles/system-cycle-manager/operational_feedback/potential_enhancements.md", should_read_entire_file=true)
    
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/potential_enhancements.md", "Update potential enhancements", 
    """
    # Update status of completed enhancement
    ## [Enhancement Title]
    
    * **Status**: Completed
    
    # Add new enhancement opportunities if identified
    ## [New Enhancement Title]

    * **Priority**: [High/Medium/Low]
    * **Complexity**: [High/Medium/Low]
    * **Dependencies**: [List of dependencies, if any]
    * **Description**: [Detailed description]
    * **Implementation Notes**: [Key implementation details]
    * **Success Criteria**: [Verification criteria]
    * **Status**: Pending
    """)
    ```
    *   **(Boundary Enforcement)**: Verify completion summary contains all required sections
    *   **(Error Handling)**: If file creation/update fails, log error but continue with remaining steps

5.  **Check for Cross-Cycle Enhancements and Errors**:
    *   Check for p3-master-cycle enhancements and system-cycle-manager errors:
    ```
    # Read p3-master-cycle enhancements and check for notifications
    read_file("1000xcycles/p3-master-cycle/operational_feedback/potential_enhancements.md", should_read_entire_file=true)
    list_dir("1000xcycles/p3-master-cycle/operational_feedback/notifications/")
    
    # Check for unresolved system-cycle-manager errors
    list_dir("1000xcycles/system-cycle-manager/operational_feedback/system_errors/")
    
    # For Critical/High priority unresolved errors, consider adding to potential enhancements
    ```
    *   Process gathered information:
        - Analyze and consider enhancing p3-master-cycle enhancement list based on current cycle learnings
        - Check for p3-master-cycle notifications
        - Identify any high-priority unresolved system-cycle-manager errors
    *   **(Boundary Enforcement)**: Verify cross-cycle enhancement suggestions are appropriate
    *   **(Error Handling)**: If files don't exist, create them with initial enhancement suggestions

6.  **Update Cycle State and Prepare for Autonomous Transition**:
    *   Update cycle state and prepare for autonomous transition in a consolidated operation:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update cycle state
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update status to completed", 
    """
    # Current Cycle Status

    **Cycle ID**: [extracted_cycle_id]
    **Status**: Completed
    **Operation Mode**: [current_operation_mode]
    **Selected Option**: [selected_option]
    **Current Phase**: Completion

    // ... existing progress summary ...

    ## Recent Logs

    **[timestamp] Completion**: [completion_summary]
    
    // ... existing logs ...
    """)
    
    # If in AUTONOMOUS_MODE, create cycle state preservation file
    if (operation_mode == "AUTONOMOUS_MODE") {
        # Boundary Check (Conceptual): 
        # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/cycle_state.md")
        # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
        # and is not prohibited (p3_handout/, *.mdc).
        # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
        # If violation detected, log to boundary_violations.md and abort/skip edit_file.
        edit_file("1000xcycles/system-cycle-manager/operational_feedback/cycle_state.md", "Preserve state for autonomous transition", 
        """
        # Cycle State Preservation

        **Source Cycle ID**: [Current cycle ID]
        **Completion Date**: [Current date]
        **Operation Mode**: AUTONOMOUS_MODE
        **Completed Enhancement**: [Enhancement name]
        
        ## Selected Next Option
        
        **Option**: [Selected option number and description]
        **Selection Rationale**: [Why this option was selected]
        
        ## Context Preservation
        
        **Key Learnings**: [Important learnings from current cycle]
        **Critical Files**: [List of files that provide essential context]
        **Enhancement Progression**: [How this fits into the overall enhancement sequence]
        """)
    }
    ```
    *   **(Boundary Enforcement)**: Verify cycle state updates are complete and accurate
    *   **(Error Handling)**: If update fails, retry with minimal changes

7.  **Prepare Next User Request and Signal Completion**:
    *   For AUTONOMOUS_MODE, prepare the next user request and signal completion:
    ```
    # If in AUTONOMOUS_MODE, prepare next user request
    if (operation_mode == "AUTONOMOUS_MODE") {
        # Determine the next option to select based on system state:
        # - If p3-master-cycle notifications exist, select OPTION 1
        # - If system-cycle-manager errors exist, select OPTION 2
        # - Otherwise, select OPTION 4 (AUTONOMOUS mode) to process potential enhancements
        
        # Boundary Check (Conceptual): 
        # Verify target_file ("1000xcycles/system-cycle-manager/plans/autonomous_next_request.md")
        # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
        # and is not prohibited (p3_handout/, *.mdc).
        # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
        # If violation detected, log to boundary_violations.md and abort/skip edit_file.
        edit_file("1000xcycles/system-cycle-manager/plans/autonomous_next_request.md", "Prepare next autonomous request", 
        """
        # USER REQUEST File
        # This file is exclusively for storing USER REQUEST content to be read and processed by 1000xdev.
        # Notes and personal content should be kept in notes.md.
        
        ## USER REQUEST SECTION
        
        # --- OPTION SELECTION ---
        [Selected Option]
        
        # --- OPERATION MODE ---
        # For options 1, 2, and 4, AUTONOMOUS_MODE is used automatically.
        AUTONOMOUS_MODE
        
        # --- REQUEST DETAILS ---
        # Only needed for OPTION 3 or OPTION 4
        [Details based on selected option]
        
        ## END USER REQUEST SECTION
        """)
    }
    ```
    *   Indicate that the cycle is now complete with:
        - Summary of key achievements
        - If system errors were resolved, highlight these accomplishments
        - If in AUTONOMOUS_MODE, indicate that the next cycle will start automatically with `run:system-cycle-manager/1`
        - If in USER_DIRECTED_MODE, note that a new cycle can be started with `run:system-cycle-manager/1`
    *   **(Boundary Enforcement)**: Verify next user request is properly formatted (if in AUTONOMOUS_MODE)
    *   **(Error Handling)**: If preparation fails, provide a clear template to copy manually

## Special Considerations

1. **Autonomous Mode Operation**:
   * When in AUTONOMOUS_MODE, actively prepare for the next cycle
   * Select the next enhancement based on defined criteria
   * Preserve state information for continuity between cycles
   * Generate appropriate user request for the next cycle
   * Set up automatic transition to step 1

2. **Documentation Completeness**:
   * Ensure all significant aspects of the cycle are documented
   * Include both successes and challenges
   * Document learnings for future reference
   * Preserve context for the next cycle

3. **Enhancement Tracking**:
   * Carefully document potential future enhancements
   * Link enhancements to current cycle experiences
   * Prioritize enhancements for future cycles
   * Update status of completed enhancements
   * Consider next option selection based on the current system state

4. **Focus on p3-master-cycle**:
   * Prioritize enhancements that support p3-master-cycle
   * Ensure cycle-manager improvements ultimately benefit p3-master-cycle
   * Track progress toward project completion
   * Document cycle-specific improvements separately

5. **Self-Enhancement Capabilities**:
   * Document opportunities to improve the cycle manager itself
   * Identify patterns that could be optimized
   * Suggest process improvements based on execution experience
   * Include these in potential_enhancements.md

6. **System Error Resolution**:
   * Update system error status to "Resolved" when successfully addressed
   * Include detailed resolution notes in the error file
   * Reference the cycle that resolved the error
   * Consider unresolved Critical/High errors for the next cycle
   * Track error resolution metrics in completion summary

7. **Cycle Metrics**:
   * Consider tracking key metrics such as:
     * Number of files modified
     * Number of enhancements implemented
     * Number of system errors resolved
     * Key achievements
     * Lessons learned

## Boundary Enforcement

1. **Input Validation**:
   * Verify cycle has completed verification phase
   * Validate operation mode is correctly identified
   * Check for required implementation results
   * Ensure system error information is accurate

2. **Output Validation**:
   * Verify completion summary contains all required sections
   * Ensure cycle state updates are complete and accurate
   * Validate enhancement updates maintain consistent format
   * Check that next user request is properly formatted (for AUTONOMOUS_MODE)

3. **Error Recovery**:
   * Preserve critical cycle information even if some updates fail
   * Document any issues in completion logs
   * Ensure system remains in a stable state
   * Provide manual instructions if automated steps fail 