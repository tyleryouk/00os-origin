# Process: Implementation

## Goal: Implement the enhancement according to the implementation plan with proper tracking and verification

## Steps:

1.  **Read Guidelines**
    - 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/3-planning-process-guidelines.md
    - 1000xbrain/guidelines/cycle-management/cycle-patterns.md
    - 1000xbrain/guidelines/planning/implementation-planning.md
    ```
    *   **(Boundary Enforcement)**: Verify all documentation files exist and contain required content
    *   **(Error Handling)**: If any documentation file is missing or incomplete, log the issue and continue with available information

2.  **Check Implementation Plan and Initialize Context**:
    *   Verify implementation plan and gather context information in a consolidated operation:
    ```
    # Read implementation context in a single logical group
    read_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_plan.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_progress.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", should_read_entire_file=true)
    ```
    *   Process gathered information:
        - Verify plan contains all necessary sections (Overview, Phases, Strategy, Verification)
        - Determine current iteration number and status
        - Extract cycle ID and current phase
    *   **(Boundary Enforcement)**: Validate implementation plan content and structure
    *   **(Error Handling)**: If plan is incomplete or missing, log error and suggest running planning process

3.  **Initialize Implementation Iteration**:
    *   Create or update iteration document with clear structure:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/implementation_iteration.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create or update iteration document
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_iteration.md", "Initialize implementation iteration", 
    """
    # Implementation Iteration [Number]

    **Cycle ID**: [from current_cycle.md]
    **Iteration Started**: [timestamp]
    **Target Completion**: [estimated completion timestamp]
    **Status**: In Progress

    ## Iteration Goals

    * [Goal 1]
    * [Goal 2]
    * ...

    ## Tasks for This Iteration

    1. **[Task 1]**:
       * **Priority**: [High/Medium/Low]
       * **Estimated Effort**: [Small/Medium/Large]
       * **Dependencies**: [Any prerequisites]
       * **Implementation Approach**: [Brief description]
       * **Status**: Not Started
       * **Notes**: [Initial notes]

    2. **[Task 2]**:
       * **Priority**: [High/Medium/Low]
       * **Estimated Effort**: [Small/Medium/Large]
       * **Dependencies**: [Any prerequisites]
       * **Implementation Approach**: [Brief description]
       * **Status**: Not Started
       * **Notes**: [Initial notes]

    ## Verification Strategy

    * **Testing Approach**: [Description of how tasks will be verified]
    * **Acceptance Criteria**: [Specific criteria for iteration success]

    ## Iteration Log

    * [Timestamp]: Iteration initiated
    """)
    ```
    *   **(Boundary Enforcement)**: Verify iteration document contains all required sections
    *   **(Error Handling)**: If iteration document creation fails, retry with simplified format

4.  **Implement Tasks**:
    *   Execute tasks in order of priority and dependencies:
        *   For each task:
            *   Update task status to "In Progress" in iteration document
            *   Execute necessary file operations (e.g., `edit_file`, `delete_file`)
                # Boundary Check (Conceptual): 
                # Before each edit_file/delete_file call within a task, verify target_file
                # against allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
                # and prohibited paths (p3_handout/, *.mdc).
                # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
                # If violation detected, log to boundary_violations.md and abort/skip operation.
            *   Verify file changes meet requirements
            *   Update task status to "Completed" with notes
            *   Update iteration log with completion timestamp
    *   **(Boundary Enforcement)**: Validate all task outputs against requirements
    *   **(Error Handling)**: If a task fails, document the issue, update task status to "Blocked", and continue with remaining tasks

5.  **Verify Implementation**:
    *   Perform comprehensive verification of completed tasks:
        *   Review completed tasks against requirements
        *   Run verification steps per implementation plan
        *   Document verification results in iteration document
    *   **(Boundary Enforcement)**: Ensure verification covers all acceptance criteria
    *   **(Error Handling)**: If verification fails, document issues, update affected tasks to "Needs Revision", and perform necessary corrections

6.  **Update Progress and Status**:
    *   Update implementation progress and cycle status in a consolidated operation:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/implementation_progress.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update implementation progress
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_progress.md", "Update implementation progress", 
    """
    # Implementation Progress

    **Cycle ID**: [from current_cycle.md]
    **Last Updated**: [timestamp]
    **Overall Progress**: [percentage]

    ## Current Iteration

    * **Iteration Number**: [number]
    * **Status**: [In Progress/Completed]
    * **Tasks Completed**: [count] / [total]
    * **Issues Encountered**: [count]

    ## Task Status Summary

    * **Not Started**: [count]
    * **In Progress**: [count]
    * **Completed**: [count]
    * **Blocked**: [count]
    * **Needs Revision**: [count]

    ## Iteration History

    [Existing iteration history]
    
    [Current iteration if completed]:
    * **Started**: [timestamp]
    * **Completed**: [timestamp]
    * **Tasks Completed**: [count] / [total]
    * **Key Accomplishments**: [bullet points]

    ## Notes

    * [Any additional notes about implementation progress]
    """)

    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update cycle status
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update cycle status", 
    """
    # Update relevant sections only
    **Status**: [Implementation Complete/Implementation Iteration [Number] Complete/Implementation Iteration [Number] In Progress]
    
    ## Recent Logs
    
    **[timestamp] Implementation**: [Implementation progress update]
    
    [Add appropriate iteration results section if iteration is complete]
    """)
    ```
    *   **(Boundary Enforcement)**: Verify progress and status updates contain all required information
    *   **(Error Handling)**: If updates fail, log errors but proceed

7.  **Signal Completion or Continue**:
    *   Determine next steps based on implementation status:
        *   If implementation is complete:
            *   Indicate that implementation is complete
            *   Note that the next step is to verify the implementation using `run:system-cycle-manager/5`
        *   If more iterations are needed:
            *   Indicate that the current iteration is complete
            *   Note that the next iteration should be started using `run:system-cycle-manager/4` again
    *   **(Boundary Enforcement)**: Verify correct next steps are provided
    *   **(Error Handling)**: If unable to determine completion status, suggest continuation

## Special Considerations

1. **Documentation Reading Priority**:
   * Reading master project documentation is THE HIGHEST PRIORITY
   * All implementation must be based on thorough understanding of documentation
   * Always use chunking to ensure complete document coverage

2. **Incremental Implementation**:
   * Prioritize tasks that provide immediate value
   * Break complex changes into smaller, manageable iterations
   * Maintain a working system at the end of each iteration

3. **Change Management**:
   * Document all changes thoroughly
   * Update affected documentation accordingly
   * Consider backward compatibility when applicable

4. **Code Quality**:
   * Follow established patterns and conventions
   * Ensure consistent formatting and organization
   * Optimize for readability and maintainability

5. **Error Handling**:
   * Handle errors gracefully during implementation
   * Document error conditions and recovery strategies
   * Implement robust failure recovery mechanisms

## Boundary Enforcement

1. **Input Validation**:
   * Verify all file paths before attempting operations
   * Check for expected file content formats before processing
   * Validate task dependencies before task execution
   * Ensure implementation plan is complete and valid

2. **Output Validation**:
   * Verify all file operations produce expected results
   * Confirm system state consistency after changes
   * Ensure all logs and progress tracking reflect actual state
   * Validate that implementation meets all requirements

3. **Error Recovery**:
   * Log all errors with clear context and timestamps
   * For transient errors, retry with exponential backoff
   * For persistent errors, document issue and continue with available information
   * For fatal errors, abort current task, document issue, proceed to next task if possible

## Implementation Strategies

### Iteration Planning

1. **Scope Management**:
   * Keep iterations focused and manageable
   * Group related tasks in the same iteration
   * Consider dependencies between tasks
   * Aim for 20-30 minute iterations when possible

2. **Progress Tracking**:
   * Clearly document completed vs. remaining tasks
   * Track progress at both task and phase levels
   * Use percentage complete for overall assessment
   * Record any scope adjustments between iterations

3. **Iteration Consistency**:
   * Maintain consistent structure across iterations
   * Ensure proper state updates between iterations
   * Preserve implementation context between iterations

### Component Creation

When creating new components:

1. **Command Files**:
   * Follow the standard 7-step format
   * Include proper dynamic execution markers
   * Reference appropriate process files
   * Include next step information

2. **Process Files**:
   * Include clear goal statement
   * Define specific steps
   * Include error handling for each step
   * Follow consistent formatting

3. **Knowledge Files**:
   * Organize content logically
   * Include comprehensive information
   * Follow standard knowledge file structure
   * Ensure clarity and accessibility

4. **Operational Feedback**:
   * Create appropriate tracking structures
   * Include templates for consistency
   * Ensure proper status tracking
   * Follow standard formats 