# Process: Planning

## Goal: Create a detailed implementation plan based on the requirements analysis

## Steps:

1.  **Read Guidelines**
    - 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/3-planning-process-guidelines.md
    - 1000xbrain/guidelines/cycle-management/cycle-patterns.md
    - 1000xbrain/guidelines/planning/implementation-planning.md
    ```
    *   **(Boundary Enforcement)**: Verify all documentation files exist and contain required content
    *   **(Error Handling)**: If any documentation file is missing or incomplete, log the issue and continue with available information

2.  **Gather Context and Requirements**:
    *   Load cycle status and analyzed requirements in a consolidated operation:
    ```
    # Read cycle context in a single logical group
    read_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/change_request.md", should_read_entire_file=true)
    ```
    *   Process gathered information:
        - Verify requirement analysis is complete
        - Extract key requirements and priorities
        - Identify cycle ID and current phase
    *   **(Boundary Enforcement)**: Validate cycle status and required context information
    *   **(Error Handling)**: If required files don't exist or requirement analysis is incomplete, log error and exit planning process

3.  **Define Implementation Tasks and Phases**:
    *   Based on requirements analysis, define specific tasks and implementation phases:
        *   Identify files that need to be created, modified, or deleted
        *   Break down each enhancement into discrete, manageable tasks
        *   Organize tasks into logical implementation phases
        *   Prioritize tasks based on dependencies and estimated effort
    *   **(Boundary Enforcement)**: Ensure all requirements are covered by defined tasks
    *   **(Error Handling)**: If tasks cannot be clearly defined from requirements, request additional information

4.  **Create Implementation Plan Document**:
    *   Create a comprehensive implementation plan with all required sections:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/implementation_plan.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create implementation plan
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_plan.md", "Create implementation plan", """
    # Implementation Plan

    **Cycle ID**: [from current_cycle.md]
    **Plan Created**: [timestamp]
    **Implementation Approach**: [approach]

    ## Overview

    [High-level summary of the implementation approach]

    ## Analysis Summary

    [Brief summary of requirements analysis results]

    ## Phases

    ### Phase 1: [First Phase Name]

    **Objective**: [Phase objective]
    **Tasks**:
    1. [Task 1]
       * **Files**: [affected files]
       * **Changes**: [description of changes]
       * **Dependencies**: [dependencies]
    
    2. [Task 2]
       * **Files**: [affected files]
       * **Changes**: [description of changes]
       * **Dependencies**: [dependencies]

    ... [Additional phases] ...

    ## Implementation Strategy

    **Iterative Approach**:
    * **Iteration 1**: [Scope]
    * **Iteration 2**: [Scope]
    ... [Additional iterations as needed] ...

    ## Verification Approach

    [How the implementation will be verified]

    ## Risk Assessment

    **Potential Issues**:
    * [Risk 1]: [Mitigation strategy]
    * [Risk 2]: [Mitigation strategy]

    ## Next Steps

    1. Begin implementation with Iteration 1
    2. Complete each phase in sequence
    3. Verify functionality after each phase
    """)
    ```
    *   **(Boundary Enforcement)**: Verify plan contains all required sections and addresses all requirements
    *   **(Error Handling)**: If plan creation fails, retry with alternative structure or document partial plan

5.  **Set Up Implementation Tracking Framework**:
    *   Create all required tracking documents in a consolidated operation:
    ```
    # Create implementation tracking framework (consolidated operation)
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/implementation_progress.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_progress.md", "Create implementation progress tracking", """
    # Implementation Progress

    **Cycle ID**: [from current_cycle.md]
    **Last Updated**: [timestamp]
    **Overall Progress**: 0%

    ## Current Iteration
    
    * **Iteration Number**: 1
    * **Status**: Not Started
    * **Tasks Completed**: 0 / [total tasks]
    * **Issues Encountered**: 0

    ## Task Status Summary

    * **Not Started**: [count]
    * **In Progress**: 0
    * **Completed**: 0
    * **Blocked**: 0
    * **Needs Revision**: 0

    ## Iteration History

    [No completed iterations yet]

    ## Upcoming Tasks

    ### Task: [Task 1]
    * **Priority**: [High/Medium/Low]
    * **Estimated Effort**: [Small/Medium/Large]
    * **Dependencies**: [Any prerequisites]
    * **Implementation Approach**: [Brief description]
    * **Status**: Not Started

    [Additional tasks...]

    ## Upcoming Iterations

    ### Iteration 1: [Phase Name]
    * **Planned Start**: [planned start date]
    * **Status**: Not Started
    * **Tasks**: 
      - [Task 1]
      - [Task 2]
      - [...]

    [Additional iterations...]

    ## Notes

    * Implementation has not yet begun.
    * Plan is in place and ready for execution.
    """)

    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/implementation_iteration.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_iteration.md", "Create implementation iteration tracking", """
    # Implementation Iteration 1

    **Cycle ID**: [from current_cycle.md]
    **Iteration Started**: [will be filled when started]
    **Target Completion**: [estimated completion date]
    **Status**: Not Started

    ## Iteration Goals

    * [Goal 1]
    * [Goal 2]
    * ...

    ## Tasks for This Iteration

    1. **[Task 1]**:
       * **Priority**: [High/Medium/Low]
       * **Estimated Effort**: [Small/Medium/Large]
       * **Dependencies**: [Any prerequisites]
       * **Implementation Approach**: [Brief description]
       * **Status**: Not Started
       * **Notes**: [Initial notes]

    2. **[Task 2]**:
       * **Priority**: [High/Medium/Low]
       * **Estimated Effort**: [Small/Medium/Large]
       * **Dependencies**: [Any prerequisites]
       * **Implementation Approach**: [Brief description]
       * **Status**: Not Started
       * **Notes**: [Initial notes]

    ## Verification Strategy

    * **Testing Approach**: [Description of how tasks will be verified]
    * **Acceptance Criteria**: [Specific criteria for iteration success]

    ## Iteration Log

    * [Will be populated during implementation]
    """)
    ```
    *   **(Boundary Enforcement)**: Validate tracking documents contain all required sections and consistent information
    *   **(Error Handling)**: If tracking setup fails, retry with simplified structure but ensure core tracking elements are in place

6.  **Update Cycle Status**:
    *   Update cycle status to reflect planning completion:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update cycle status
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update cycle status", """
    # Update relevant sections only
    **Status**: Planning Complete
    **Current Phase**: Ready for Implementation
    
    ## Recent Logs
    
    **[timestamp] Planning**: Implementation plan created with [X] phases and [Y] total tasks. Ready for implementation.
    """)
    ```
    *   **(Boundary Enforcement)**: Ensure status update includes all required information
    *   **(Error Handling)**: If status update fails, log error but proceed with signal

7.  **Signal Completion**:
    *   Indicate that planning is complete
    *   Note that the next step is `run:system-cycle-manager/4`
    *   Provide a brief summary of the implementation plan structure
    *   **(Boundary Enforcement)**: Verify correct next steps are provided
    *   **(Error Handling)**: If unable to determine completion status, suggest manual assessment

## Special Considerations

1. **Documentation Reading Priority**:
   * Reading master project documentation is THE HIGHEST PRIORITY
   * All implementation planning must be based on thorough understanding of documentation
   * Always use chunking to ensure complete document coverage

2. **Iterative Implementation**:
   * Always break implementation into clear iterations
   * Each iteration should have concrete, verifiable exit criteria
   * Progress should be trackable and measurable

3. **Plan Flexibility**:
   * Implementation plan should be adaptive to discoveries during implementation
   * Allow for refinement of tasks as work progresses
   * Document assumptions that may need validation

4. **Testing Strategy**:
   * Include verification methods for each task
   * Define how implementation success will be measured
   * Consider edge cases and potential issues

5. **Documentation**:
   * Planning documents should be clear enough to allow implementation without referring back to requirements
   * Use consistent terminology throughout planning documents
   * Provide enough detail for implementation but avoid over-specification

## Boundary Enforcement

1. **Input Validation**:
   * Verify requirement analysis is complete before planning
   * Validate all requirements are clear and actionable
   * Ensure all documentation has been thoroughly reviewed
   * Confirm cycle ID and status are consistent

2. **Output Validation**:
   * Verify implementation plan covers all requirements
   * Ensure all tasks have clear definitions and acceptance criteria
   * Confirm tracking documents are properly initialized
   * Validate that cycle status is properly updated

3. **Error Recovery**:
   * For missing requirement details, document assumptions and continue
   * For ambiguous requirements, provide best interpretation and flag for review
   * For tracking document creation failures, ensure minimal viable tracking is in place
   * For plan structure issues, adapt to available information while maintaining core sections 