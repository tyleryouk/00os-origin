# Process: Initiation

## Goal: Initialize a new cycle manager cycle and prepare the environment with option selection template.

## Steps:

1.  **Create Boundary Violation Log**:
    *   Ensure the boundary violation log file exists.
    ```
    # Create boundary violation log if it doesn't exist
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/boundary_violations.md", "Create boundary violation log", 
    "# Boundary Violations Log\\n\\nThis log tracks attempted boundary violations during cycle execution.\\n")
    ```
    *   **(Boundary Enforcement)**: Verify the operational_feedback directory exists.
    *   **(Error Handling)**: If creation fails, log error to notes.md and continue.

2.  **Initialize Environment and Create Cycle Tracking Information**:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create or update cycle tracking file
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Create cycle tracking information", 
    """
    # Current Cycle Status

    **Cycle ID**: [identifier]
    **Status**: Initialized
    **Operation Mode**: AUTONOMOUS_MODE

    ## Current Phase

    Initialization complete. Ready for option selection and requirement analysis.
    
    ## Recent Logs

    **[timestamp] Initialization**: Cycle initialized successfully.
    """)
    ```
    *   **(Boundary Enforcement)**: Verify directory structure is created and writable
    *   **(Error Handling)**: If directory creation fails, retry creating each directory individually

3.  **Collect System State Information**:
    *   Check for notifications, errors, and enhancements in a consolidated operation:
    ```
    # Check all system state information in a single logical group
    list_dir("1000xcycles/p3-master-cycle/operational_feedback/notifications/")
    list_dir("1000xcycles/system-cycle-manager/operational_feedback/system_errors/")
    read_file("1000xcycles/system-cycle-manager/operational_feedback/potential_enhancements.md", should_read_entire_file=true)
    ```
    *   Process collected information:
        - Count notifications (excluding README.md and resolution-complete.md)
        - Count system errors (excluding README.md)
        - Identify available enhancements
    *   **(Boundary Enforcement)**: Validate directory contents and file structure
    *   **(Error Handling)**: If directory checking fails, log warning and assume none exist

4.  **Create User Request Template and Update Status**:
    *   Create user request template and update status in a consolidated operation:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/plans/user_request.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create user request template
    edit_file("1000xcycles/system-cycle-manager/plans/user_request.md", "Create option selection template", 
    """
    # USER REQUEST File
    # This file is exclusively for storing USER REQUEST content to be read and processed by 1000xdev.
    # Notes and personal content should be kept in notes.md.

    ## USER REQUEST SECTION

    # --- OPTION SELECTION ---
    # Select ONE option by removing the comment marker (#) from your selection:
    # OPTION 1: Resolve errors in p3-master-cycle notifications (autonomous mode)
    # OPTION 2: Resolve errors in system-cycle-manager system_errors (autonomous mode)
    # OPTION 3: New USER_DIRECTED request (requires filling all template fields below)
    # OPTION 4: AUTONOMOUS mode (process potential enhancements automatically)

    # --- OPERATION MODE ---
    # Note: For options 1, 2, and 4, AUTONOMOUS_MODE will be used automatically.
    # For option 3, remove the comment marker from your selection:
    # AUTONOMOUS_MODE
    # USER_DIRECTED_MODE

    # --- REQUEST DETAILS (Only needed for OPTION 3) ---
    # Directive: [Enhancement|Fix|Refactor|Analysis]
    # Target Cycle: [domain/cycle-name]
    # Enhancement Name: [Brief descriptive name]
    # Priority: [High|Medium|Low]

    # Enhancement Details
    [Provide a clear description of what needs to be done. Be specific about requirements.]

    # Focus Areas (Optional)
    [Specific files or components that should receive attention]

    # Autonomous Settings (Only used in AUTONOMOUS_MODE)
    # Primary Focus: [p3-master-cycle|system-cycle-manager|both]
    # Self-Enhancement: [Enabled|Disabled]
    # Enhancement Selection: [Highest Priority|Balance Priority and Complexity|User Suggestion]

    ## END USER REQUEST SECTION
    """)

    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update current_cycle.md with option availability information
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update with option availability", 
    """
    ## Option Availability

    [notification_count] p3-master-cycle notifications found:
    [notification_list]

    [error_count] system-cycle-manager system errors found:
    [error_list]

    Multiple potential enhancements available in potential_enhancements.md

    **Recommended Priority**: [recommended_option]
    """)
    ```
    *   **(Boundary Enforcement)**: Verify template files are created with all required sections
    *   **(Error Handling)**: If template creation fails, retry with simplified format

5.  **Log Any System Errors and Signal Completion**:
    *   Complete the initialization process:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/plans/notes.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create a notes file for the cycle
    edit_file("1000xcycles/system-cycle-manager/plans/notes.md", "Create cycle notes file", 
    """
    # Cycle Notes

    ## Initialization Notes
    * Cycle initialized on [timestamp]
    * [Any errors or warnings encountered during initialization]
    * [Any special considerations for this cycle]

    ## Option Selection Guidance
    * [Recommendations based on system state]
    * [Any context information that might be helpful]

    ## Progress Notes
    * [This section will be updated as the cycle progresses]
    """)
    ```
    *   Indicate completion with next steps:
        - Note that initialization is complete
        - Provide instructions for option selection in user_request.md
        - Indicate that the next step is `run:system-cycle-manager/2`
    *   **(Boundary Enforcement)**: Verify all required files have been created
    *   **(Error Handling)**: Log any issues encountered during initialization

## Special Considerations

1. **Menu Option Guidance**:
   * Present clear menu options with appropriate recommendations
   * Ensure user_request.md template is clear and user-friendly
   * Provide sufficient information for informed option selection

2. **Notification and Error Visibility**:
   * Make notification and error counts visible in current_cycle.md
   * Provide recommendations based on notification, error, and enhancement presence
   * Ensure user is aware of all issues that need attention

3. **Option Selection Simplicity**:
   * Keep the option selection process simple and straightforward
   * Clearly explain what each option will do
   * Set appropriate mode defaults for each option
   * Minimize cognitive load during option selection

4. **Error Resolution Priority**:
   * Always prioritize p3-master-cycle error notifications over system-cycle-manager internal errors
   * Address p3-master-cycle errors immediately during current cycle
   * Log system-cycle-manager errors for future enhancement cycles

## Boundary Enforcement

1. **Input Validation**:
   * Verify valid cycle ID format and uniqueness
   * Check for filesystem access permissions 
   * Validate system state information structure

2. **Output Validation**:
   * Confirm all required directories and files exist
   * Verify operational feedback files contain mandatory sections
   * Ensure cycle documentation is complete and accurate

3. **Error Recovery**:
   * Use alternative approaches if primary operations fail
   * Document any issues in cycle notes
   * Ensure system remains in a consistent state 