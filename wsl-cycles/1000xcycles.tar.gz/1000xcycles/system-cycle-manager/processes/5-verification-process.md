# Process: Verification

# Defines the steps for verifying that cycle implementations meet requirements and standards.
# Follows guidelines in: 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/5-verification-process-guidelines.md

## Goal: Ensure that cycles and cycle-related components meet all requirements and adhere to standards.

## Steps:

1.  **Read Guidelines**
    - 1000xbrain/guidelines/cycle-management/system-cycle-manager-processes/3-planning-process-guidelines.md
    - 1000xbrain/guidelines/cycle-management/cycle-patterns.md
    - 1000xbrain/guidelines/planning/implementation-planning.md
    ```
    *   **(Boundary Enforcement)**: Verify all documentation files exist and contain required content
    *   **(Error Handling)**: If any documentation file is missing or incomplete, log the issue and continue with available information

2.  **Check Cycle Status and Context**:
    *   Verify cycle status and gather context information in a consolidated operation:
    ```
    # Read cycle context in a single logical group
    read_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/change_request.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_plan.md", should_read_entire_file=true)
    read_file("1000xcycles/system-cycle-manager/operational_feedback/implementation_progress.md", should_read_entire_file=true)
    ```
    *   Process gathered information:
        - Verify implementation has been completed or is ready for verification
        - Extract cycle ID and current phase
        - Identify verification criteria from implementation plan
    *   **(Boundary Enforcement)**: Validate cycle status and required context information
    *   **(Error Handling)**: If implementation is not complete, log error and suggest running implementation

3.  **Define Verification Criteria**:
    *   Based on gathered sources, define specific verification criteria:
        *   Structure compliance
        *   Content standards
        *   Functionality requirements
        *   Success criteria from change request/implementation plan
    *   Extract specific requirements from change_request.md to create a verification checklist
    *   **(Boundary Enforcement)**: Ensure verification criteria are complete and aligned with requirements
    *   **(Error Handling)**: If verification criteria cannot be established, use default criteria based on process guidelines

4.  **Initialize Verification Document**:
    *   Create or update verification document with structured template:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/verification_report.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Create or update verification document
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/verification_report.md", "Initialize verification report", """
    # Verification Report

    **Cycle ID**: [from current_cycle.md]
    **Date**: [current-date]
    **Change Request**: [reference to change_request.md]
    **Implementation Plan**: [reference to implementation_plan.md]
    **Status**: In Progress

    ## Verification Criteria

    [Extract criteria from implementation plan and change request]

    ## Verification Progress

    * Verification initiated: [timestamp]
    * Current status: In progress
    
    ## Verification Framework

    [Add verification framework based on criteria]
    
    ## Issue Tracking

    [Will be populated during verification]
    """)
    ```
    *   **(Boundary Enforcement)**: Verify verification document contains all required sections
    *   **(Error Handling)**: If document creation fails, retry with simplified format

5.  **Execute Verification Process**:
    *   Systematically verify each criterion using a consolidated approach:
        *   For structural criteria: verify file organization and structure
        *   For content criteria: verify documentation quality and completeness
        *   For functional criteria: verify process functionality
    *   Group verification tasks by category to reduce context switching:
        *   First verify command structures across all files
        *   Then verify process implementations across all files
        *   Finally verify cross-file dependencies and references
    *   **(Boundary Enforcement)**: Validate each criterion against established standards
    *   **(Error Handling)**: Document any failures or issues encountered during verification

6.  **Comprehensive Documentation Verification**:
    *   Verify documentation completeness and consistency:
        *   Check guideline coverage across all processes
        *   Verify cross-references between documents
        *   Ensure all requirements are documented
    *   Create documentation coverage matrix for reporting
    *   **(Boundary Enforcement)**: Ensure all documentation meets quality standards
    *   **(Error Handling)**: Document any documentation gaps or inconsistencies

7.  **Complete Verification Report**:
    *   Finalize verification report with comprehensive results:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/verification_report.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update verification report with results
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/verification_report.md", "Complete verification report", """
    # Update relevant sections

    ## Verification Status Summary

    [SUCCESSFUL/PARTIALLY SUCCESSFUL/FAILED]: [Brief summary]

    ## Requirements Verification

    [Add detailed verification results for each requirement]

    ## Structure Verification

    [Add detailed verification results for structural elements]

    ## Success Criteria Verification

    [Add detailed verification results for success criteria]

    ## Guideline Coverage Matrix

    [Add the completed coverage matrix]

    ## Issues Requiring Refinement

    [Add identified issues]

    ## Overall Verification Status

    [Add final status and conclusion]

    ## Next Steps

    [Add recommended next steps]
    """)
    ```
    *   **(Boundary Enforcement)**: Verify report contains complete assessment for all criteria
    *   **(Error Handling)**: If report completion fails, document partial results and continue

8.  **Update Cycle Status**:
    *   Update cycle status to reflect verification completion:
    ```
    # Boundary Check (Conceptual): 
    # Verify target_file ("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md")
    # is within allowed directories (1000xcycles/, 1000xbrain/, 1000xrules/) 
    # and is not prohibited (p3_handout/, *.mdc).
    # Reference: 1000xbrain/guidelines/cycle-management/boundary-enforcement.md
    # If violation detected, log to boundary_violations.md and abort/skip edit_file.

    # Update cycle status
    edit_file("1000xcycles/system-cycle-manager/operational_feedback/current_cycle.md", "Update cycle status", """
    # Update relevant sections only
    **Status**: Verification Complete
    
    ## Recent Logs
    
    **[timestamp] Verification**: Completed verification process. [Summary of findings]
    
    ## Verification Results
    
    **Verification Status**: [SUCCESSFUL/PARTIALLY SUCCESSFUL/FAILED]
    **Issues Identified**: [count]
    **Critical Issues**: [count]
    **Non-Critical Issues**: [count]
    
    [Add verification summary details]
    """)
    ```
    *   **(Boundary Enforcement)**: Ensure status update includes all required information
    *   **(Error Handling)**: If status update fails, log error but proceed with signal

9.  **Signal Completion**:
    *   Determine next steps based on verification results:
        *   If verification was successful with no issues:
            *   Indicate that verification is complete
            *   Recommend completion using `run:system-cycle-manager/7`
        *   If verification identified issues requiring refinement:
            *   Indicate that verification is complete but issues were found
            *   Recommend refinement using `run:system-cycle-manager/6`
    *   **(Boundary Enforcement)**: Verify correct next steps are provided
    *   **(Error Handling)**: If unable to determine verification status, suggest manual assessment

## Special Considerations

1. **Self-Verification**:
   * When verifying the cycle-manager itself, apply extra scrutiny
   * The cycle-manager should exemplify best practices

2. **Critical Versus Non-Critical Issues**:
   * Distinguish between critical issues (requiring immediate refinement)
   * And non-critical issues (can be addressed in future cycles)

3. **Documentation Quality**:
   * Pay special attention to documentation quality
   * Clear documentation is essential for cycle management

4. **Standards Evolution**:
   * Consider whether standards themselves need updating
   * Recommend standards improvements when appropriate 

5. **Verification Completeness**:
   * Ensure verification covers ALL requirements from change request
   * Provide specific evidence rather than general statements
   * Use concrete examples with file paths and line numbers

## Boundary Enforcement

1. **Input Validation**:
   * Verify all cycle status information before proceeding
   * Validate implementation completeness before verification
   * Ensure all verification criteria are well-defined
   * Confirm all required source documents are available

2. **Output Validation**:
   * Verify verification report covers all criteria
   * Ensure all issues are properly documented
   * Confirm status updates reflect actual verification state
   * Validate that next steps are appropriate for verification results

3. **Error Recovery**:
   * For missing documentation, proceed with available information and document gaps
   * For incomplete implementations, document status and recommend completing implementation
   * For verification failures, document specific issues and recommend targeted refinement
   * For critical failures, provide clear diagnostics and manual intervention steps

## Verification Standards Reference

### Command File Standards

* Files named 1.md through 7.md
* Each file includes:
  * Clear title
  * Appropriate process reference
  * Next step information
  * Dynamic execution markers

### Process File Standards

* Clear goal statement
* Well-defined steps
* Error handling for each step
* Appropriate templates
* Complete implementation
* **(New)** Explicit guideline reading steps
* **(New)** Context rebuilding at beginning

### Knowledge File Standards

* Clear organization
* Comprehensive content
* Cross-referencing
* Up-to-date information
* **(New)** Actionable guidance

### Unified Model Standards

* USER REQUEST SECTION template
* Mode detection logic
* Equivalent execution paths
* Enhancement documentation

## Special Considerations

1. **Self-Verification**:
   * When verifying the cycle-manager itself, apply extra scrutiny
   * The cycle-manager should exemplify best practices

2. **Critical Versus Non-Critical Issues**:
   * Distinguish between critical issues (requiring immediate refinement)
   * And non-critical issues (can be addressed in future cycles)

3. **Documentation Quality**:
   * Pay special attention to documentation quality
   * Clear documentation is essential for cycle management

4. **Standards Evolution**:
   * Consider whether standards themselves need updating
   * Recommend standards improvements when appropriate 

5. **(New) Verification Completeness**:
   * Ensure verification covers ALL requirements from change request
   * Provide specific evidence rather than general statements
   * Use concrete examples with file paths and line numbers 