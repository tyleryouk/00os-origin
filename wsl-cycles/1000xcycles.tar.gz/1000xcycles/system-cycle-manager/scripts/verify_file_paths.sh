#!/bin/bash

# File Path Verification Script
# This script verifies the existence of file paths extracted from implementation_log.md
# Created as part of CM-2023-12-17-001 (File Location Consistency Fix)

# Usage: ./verify_file_paths.sh [input_file] [output_file]
# If no input file is provided, it will use stdin
# If no output file is provided, it will output to stdout

# Set default input and output
INPUT=${1:-/dev/stdin}
OUTPUT=${2:-/dev/stdout}

# Base directory for path verification
BASE_DIR=$(pwd)
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Initialize counters
TOTAL_PATHS=0
EXISTING_PATHS=0
MISSING_PATHS=0

# Print header to output
echo "# File Path Verification Report" > $OUTPUT
echo "**Generated**: $TIMESTAMP" >> $OUTPUT
echo "" >> $OUTPUT
echo "## Summary" >> $OUTPUT
echo "" >> $OUTPUT
echo "| Status | Count | Percentage |" >> $OUTPUT
echo "|--------|-------|------------|" >> $OUTPUT

# Create temporary files for sorting paths
TMP_FILE_ALL=$(mktemp)
TMP_FILE_EXISTING=$(mktemp)
TMP_FILE_MISSING=$(mktemp)

# Extract file paths from input (assuming one path per line)
# Note: In a real implementation, this would use grep/sed to extract paths from implementation_log.md
cat $INPUT | while read -r path; do
    # Skip empty lines and comments
    if [[ -z "$path" ]] || [[ "$path" =~ ^#.* ]]; then
        continue
    fi
    
    # Increment total paths counter
    TOTAL_PATHS=$((TOTAL_PATHS + 1))
    
    # Record in all paths file
    echo "$path" >> $TMP_FILE_ALL
    
    # Check if file exists
    if [[ -e "$BASE_DIR/$path" ]]; then
        EXISTING_PATHS=$((EXISTING_PATHS + 1))
        echo "$path" >> $TMP_FILE_EXISTING
    else
        MISSING_PATHS=$((MISSING_PATHS + 1))
        echo "$path" >> $TMP_FILE_MISSING
    fi
done

# Calculate percentages (if total paths > 0)
if [[ $TOTAL_PATHS -gt 0 ]]; then
    EXISTING_PERCENT=$(echo "scale=2; $EXISTING_PATHS * 100 / $TOTAL_PATHS" | bc)
    MISSING_PERCENT=$(echo "scale=2; $MISSING_PATHS * 100 / $TOTAL_PATHS" | bc)
else
    EXISTING_PERCENT="N/A"
    MISSING_PERCENT="N/A"
fi

# Update summary in output
echo "| Existing | $EXISTING_PATHS | $EXISTING_PERCENT% |" >> $OUTPUT
echo "| Missing | $MISSING_PATHS | $MISSING_PERCENT% |" >> $OUTPUT
echo "| **Total** | **$TOTAL_PATHS** | **100%** |" >> $OUTPUT
echo "" >> $OUTPUT

# Add detailed sections
echo "## Missing Paths" >> $OUTPUT
echo "" >> $OUTPUT
echo "The following paths were referenced but do not exist in the filesystem:" >> $OUTPUT
echo "" >> $OUTPUT
echo "| Path | Context |" >> $OUTPUT
echo "|------|---------|" >> $OUTPUT

# Add each missing path
if [[ $MISSING_PATHS -gt 0 ]]; then
    cat $TMP_FILE_MISSING | sort | uniq | while read -r path; do
        echo "| $path | Extracted from implementation_log.md |" >> $OUTPUT
    done
else
    echo "| *None* | *All paths exist* |" >> $OUTPUT
fi

echo "" >> $OUTPUT
echo "## Path Categories" >> $OUTPUT
echo "" >> $OUTPUT
echo "### Path Prefixes" >> $OUTPUT
echo "" >> $OUTPUT
echo "| Prefix | Count | Examples |" >> $OUTPUT
echo "|--------|-------|----------|" >> $OUTPUT

# Analyze path prefixes (first directory level)
cat $TMP_FILE_ALL | awk -F'/' '{print $1}' | sort | uniq -c | sort -nr | while read -r count prefix; do
    # Get a few examples
    EXAMPLES=$(grep -m 3 "^$prefix/" $TMP_FILE_ALL | tr '\n' ', ' | sed 's/,$//' | sed 's/,/, /g')
    echo "| $prefix | $count | $EXAMPLES |" >> $OUTPUT
done

echo "" >> $OUTPUT
echo "### Second-Level Directories" >> $OUTPUT
echo "" >> $OUTPUT
echo "| Directory | Count | Examples |" >> $OUTPUT
echo "|-----------|-------|----------|" >> $OUTPUT

# Analyze second-level directories
cat $TMP_FILE_ALL | awk -F'/' '{print $1"/"$2}' | sort | uniq -c | sort -nr | while read -r count dir; do
    # Get a few examples
    EXAMPLES=$(grep -m 2 "^$dir/" $TMP_FILE_ALL | tr '\n' ', ' | sed 's/,$//' | sed 's/,/, /g')
    echo "| $dir | $count | $EXAMPLES |" >> $OUTPUT
done

echo "" >> $OUTPUT
echo "## Recommendations" >> $OUTPUT
echo "" >> $OUTPUT
echo "Based on the verification results, the following actions are recommended:" >> $OUTPUT
echo "" >> $OUTPUT
echo "1. Create missing files in their correct locations" >> $OUTPUT
echo "2. Standardize directory prefixes for consistency" >> $OUTPUT
echo "3. Update references in implementation_log.md to use correct paths" >> $OUTPUT

# Clean up temp files
rm $TMP_FILE_ALL $TMP_FILE_EXISTING $TMP_FILE_MISSING

echo "Verification complete. Results written to $OUTPUT" 