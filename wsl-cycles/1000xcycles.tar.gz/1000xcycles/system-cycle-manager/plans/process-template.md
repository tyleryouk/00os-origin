# Process: [NAME]

## Goal: [CLEAR GOAL STATEMENT]

## Steps:

1. **Read User Request**:
   * Read user request to understand the specific task:
   ```
   read_file("1000xcycles/p3-master-cycle/plans/user_request.md", should_read_entire_file=true)
   ```
   * **Error Handling**: If user request file is missing or incomplete, log the error and use default assumptions

2. **Read Cycle Status**:
   * Check current cycle status:
   ```
   read_file("1000xcycles/p3-master-cycle/operational_feedback/current_cycle.md", should_read_entire_file=true)
   ```
   * **Error Handling**: If status file is missing, log the error and proceed with limited context

3. **[PROCESS-SPECIFIC STEP 1]**:
   * [Step description]
   ```
   [Tool call(s) - keep minimal]
   ```
   * **Error Handling**: [Process-specific error handling]

4. **[PROCESS-SPECIFIC STEP 2]**:
   * [Step description]
   ```
   [Tool call(s) - keep minimal]
   ```
   * **Error Handling**: [Process-specific error handling]

5. **[PROCESS-SPECIFIC STEP n]**:
   * [Step description]
   ```
   [Tool call(s) - keep minimal]
   ```
   * **Error Handling**: [Process-specific error handling]

6. **[HIY SHELL INTEGRATION STEP]** (if applicable):
   * Reference HIY shell guidance:
   ```
   read_file("1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md", should_read_entire_file=true)
   read_file("1000xcycles/p3-master-cycle/operational_feedback/additional_hiy_tests.md", should_read_entire_file=true)
   ```
   * Execute HIY shell tests:
   ```
   run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
   run_terminal_cmd(command="cd p3_handout && echo -e \"help\nquit\" | ./hiy", is_background=false)
   ```
   * **Error Handling**: If terminal commands fail, log the errors and try to understand what went wrong

7. **[HIY.C MODIFICATION STEP]** (if applicable):
   * Read current state of hiy.c:
   ```
   read_file("p3_handout/src/hiy.c", should_read_entire_file=true)
   ```
   * Make targeted edits:
   ```
   # Boundary Check: Verify target_file is EXACTLY "p3_handout/src/hiy.c"
   # If not, log violation and abort edit operation
   edit_file("p3_handout/src/hiy.c", "Implement [specific change]", 
   "// ... existing code ...\n[code changes WITHOUT comments]\n// ... existing code ...")
   ```
   * **Error Handling**: If edit fails, log the error and consider alternative approaches

8. **Update Status**:
   * Update cycle status:
   ```
   # Boundary Check: Verify target_file is within allowed directories and not prohibited
   edit_file("1000xcycles/p3-master-cycle/operational_feedback/current_cycle.md", "Update cycle status", 
   """
   # Current Cycle Status

   **Cycle ID**: [Cycle ID]
   **Status**: [New Status]
   **Current Phase**: [New Phase]

   ## Recent Logs

   **[timestamp] [Process Name]**: [Status update summary]

   // ... existing code ...
   """)
   ```
   * **Error Handling**: If update fails, log the error but proceed to completion

9. **Signal Completion**:
   * Indicate process completion
   * Note the next step is `run:p3-master-cycle/[next-command-number]`
   * Summarize what was accomplished
   * **Error Handling**: Ensure clear next steps are provided regardless of any issues

## Project Constraints

1. **⚠️ CRITICAL PROJECT CONSTRAINTS ⚠️**:
   * ONLY `p3_handout/src/hiy.c` may be edited
   * NO comments should be added during implementation
   * NO new files should be created for the project

2. **Error Handling Principles**:
   * All errors should be logged but should not halt the process unless critical
   * For non-critical errors, continue with best available information
   * For critical errors that prevent core functionality, provide clear guidance on what went wrong

3. **Tool Call Optimization**:
   * Minimize the number of tool calls to prevent context window overflow
   * NO chunking of large files - use complete file reading when possible
   * Group related tool calls together to maintain context

4. **HIY Shell Integration**:
   * Reference HIY shell guidance documents directly
   * Execute terminal commands with appropriate error handling
   * Verify HIY shell functionality after any changes to hiy.c 