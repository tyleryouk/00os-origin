## Do not delete


Create the commands, processes, and guidelines for p3-master-cycle.

p3-master-cycle will have the exact same steps, processes, and cycle guidelines as system-cycle-manager. p3-master-cycle will make tool calls to very similar cycle-related guidelines, but will ALSO make tool calls to project 3 specific guidelines and project 3 specific knowledge base files, particularly the master project documentation (35 total pages, split up into two files around 1000 and 600 lines respectively).

master project documentation: 
1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md
1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md

As you create each step for p3-master-cycle, read the command, process, and guidelines for the same step in system-cycle-manager. As you create the steps for p3-master-cycle, go one step at a time and be very detail-oriented. 

**Very important** As you create the steps in p3-master-cycle, assume that memory will be wiped for every step, and that there needs to be explicit instructions for tool calls during the process of every step to rebuild memory (tool calls to 1000xbrain/guidance/ files and BOTH files 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md and 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md during relevant stages). At least every other stage should include tool calls to the master project documentation IN FULL. 

For guidance on how to structure the cycle-commands, utilize the same sequential structure as system-cycle-manager. There should be 7 steps in the cycle. p3-master-cycle should align with similar processes, such as utilizing the USER REQUEST file for user-directed cycles, and enhancing step 7 to create a plan for next steps in the case that autonomous mode is selected during step 1 (along with all other high-level processes in system-cycle-manager). p3-master-cycle should also utilize its own operational_feedback folder for implementation plans, cycle_state, etc. If you feel like certain guidelines are too specific to system-cycle-manager, create new guidelines tailored towards project 3 code changes. If you feel like the certain aspects of system-cycle-manager processes are too specific to system-cycle-manager, you can make adjustments but try your best to make the process of each p3-master-cycle step to be as similar as possible to each system-cycle-manager.


**p3-master-cycle cycle-command is invoked**
1. Read command in 1000xcycles/p3-master-cycle/commands/{cycle-command} (step to read command is engrain in 1000xrules)
2. Read process in 1000xcycles/p3-master-cycle/processes/{process} (step to read process is engrained in cycle-command)
3. Make dynamic tool calls in processes
4. Update operational_feedback
5. Invoke next step

**system-cycle-manager cycle-command is invoked**
1. Read command in 1000xcycles/system-cycle-manager/commands/{cycle-command} (step to read command is engrain in 1000xrules)
2. Read process in 1000xcycles/system-cycle-manager/processes/{process} (step to read process is engrained in cycle-command)
3. Make dynamic tool calls in processes
4. Update operational_feedback
5. Invoke next step

During the processes of p3-The dynamic tool calls should read guidelines at least once in every process. You also need to simplify the . Somewhere in guidelines should be guidelines for cycles, which needs to be updated. You will not automatically understand how cycles work every cycle-command because your context window is limited. That is why you need to explicitly read guidelines throughout the cycle so that you do not mess up. ASSUME that your memory is wiped before EVERY step so that during the step you make adequate tool calls to build context before making any changes. This is mandatory for BOTH system-cycle-manager and p3-master-cycle.

When you are in system-cycle-manager editing the p3-master-cycle, start with the cycle-command first, then edit the processes, then edit the files in 1000xbrain (knowledge-base and guidelines). There are MANY times when you create knowledge-base and guidelines but they are never actually read because the cycle-commands and processes remain the same.


**THIS CYCLE IS ONLY FOCUSED ON ENHANCING GUIDELINES AND P3-MASTER-CYCLE**

Do not make changes to p3_handout/src/hiy.c. You can NEVER make code changes during system-cycle-manager.

The next cycle will be the first iteration of p3-master-cycle. I need p3-master-cycle and system-cycle-manager to be fully optimized before starting p3-master-cycle, because during p3-master-cycle there WILL be tool call or other cycle errors. In this case, you MUST leave notes for system-cycle-manager to come in and resolve these errors. While in the cycle of system-cycle-manager, you will ONLY make changes to the markdown files relevant to p3-master-cycle. This needs to be CLEAR so that you can switch between system-cycle-manager and p3-master-cycle for different concerns. I do NOT want to see you making code changes during system-cycle-manager. That will COMPLETELY mess up the code. p3-master-cycle is the ONLY cycle for code changes. This needs to be ENGRAINED in your processes through proper guideline files.

**Context on p3-master-cycle automatic iterations**
p3-master-cycle should be good enough to continously iterate through cycles until project 3 task manager is 100% complete AND 100% accurate as per the master project documentation in 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md and 1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md . During the steps of p3-master-cycle, there should be frequent read_file tool calls to the master project documentation. You also need to ensure that during every cycle you read the guidelines to ensure that you are writing in based on code and comment guidelines. You also need to ensure that during every cycle, there is a process for steps 7,1, and 2 to autonomously know what to do next if during step 1, I choose autonomous mode. Step 7 should prepare the next steps (like your own user request), step 1 will ask if I have a user request which will be the user-directed flow, and step 2 will read the USER REQUEST file to see if I choose autonomous or user-directed. If the choice is user-directed, you will run the cycle based on my request. If the choice is autonomous, you will run the cycle based on your own request/next-steps.


**Summary**
#### p3-master-cycle
p3-master-cycle reads guidelines and knowledge-base files, then reads the files in p3_handout and makes code changes to `p3_handout/src/hiy.c`.

#### system-cycle-manager
system-cycle-manager reads guidelines then makes changes to itself (system-cycle-manager) or makes changes to p3-master-cycle. You should NOT be making any code changes in this cycle. Again, you should NOT be making any code changes in this cycle.