# HIY Shell Integration Approach

## Overview

This document defines a standardized approach for integrating HIY shell testing and command execution across all p3-master-cycle processes. The goal is to ensure consistent, reliable interaction with the HIY shell for both testing and implementation purposes.

## Core Integration Components

### 1. Documentation Reference

All processes that interact with the HIY shell must reference these guidance documents:

```
# Primary HIY shell guidance
read_file("1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md", should_read_entire_file=true)

# Additional test cases
read_file("1000xcycles/p3-master-cycle/operational_feedback/additional_hiy_tests.md", should_read_entire_file=true)

# Comprehensive command cheatsheet
read_file("1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md", should_read_entire_file=true)
```

These documents provide a complete reference for all HIY shell commands, test cases, and expected behaviors. No chunking should be used - read the entire files to maintain full context.

### 2. Terminal Command Patterns

All HIY shell testing should follow these standardized terminal command patterns:

#### Basic Compilation

```
# Clean compilation from scratch
run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
```

#### Non-Interactive Testing

```
# Basic non-interactive testing (single command)
run_terminal_cmd(command="cd p3_handout && echo \"help\" | ./hiy", is_background=false)

# Multiple command testing
run_terminal_cmd(command="cd p3_handout && echo -e \"help\nlist\nquit\" | ./hiy", is_background=false)

# With file redirection
run_terminal_cmd(command="cd p3_handout && echo -e \"cat\nstart 1 < fox.txt\nquit\" | ./hiy", is_background=false)
```

#### Advanced Testing Techniques

For more complex tests, especially those with dynamic input or multiple commands, use:

```
# Sequence of commands with expected pauses between steps
run_terminal_cmd(command="cd p3_handout && (echo \"slow_cooker 5\"; sleep 1; echo \"startbg 1\"; sleep 1; echo \"list\"; sleep 1; echo \"quit\") | ./hiy", is_background=false)
```

For tests requiring keyboard signals (Ctrl-C, Ctrl-Z, etc.), document these specifically as requiring manual testing.

### 3. Testing Workflow

All processes should implement this testing workflow:

1. **Pre-Testing**: Before any changes to hiy.c, run baseline tests to understand current functionality
2. **Implementation**: Make targeted changes to hiy.c
3. **Post-Testing**: Re-run the same tests to verify changes worked as expected
4. **Refinement**: If issues are found, iterate with additional changes and testing

This ensures a test-driven approach that verifies each change before moving on.

## Integration in Specific Processes

### Implementation Process

The Implementation Process should contain these specific HIY shell integration steps:

```
# 1. Read HIY shell guidance
read_file("1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md", should_read_entire_file=true)
read_file("1000xcycles/p3-master-cycle/operational_feedback/additional_hiy_tests.md", should_read_entire_file=true)

# 2. Run pre-implementation tests
run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
run_terminal_cmd(command="cd p3_handout && echo -e \"help\nlist\nquit\" | ./hiy", is_background=false)

# 3. Read hiy.c
read_file("p3_handout/src/hiy.c", should_read_entire_file=true)

# 4. Make targeted changes to hiy.c
edit_file("p3_handout/src/hiy.c", "Implement specific feature", "// ... existing code ...\n[changes]\n// ... existing code ...")

# 5. Run post-implementation tests
run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
run_terminal_cmd(command="cd p3_handout && echo -e \"help\nlist\nquit\" | ./hiy", is_background=false)
```

### Testing Process

The Testing Process should focus exclusively on comprehensive HIY shell testing:

```
# 1. Read HIY shell guidance
read_file("1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md", should_read_entire_file=true)

# 2. Compile the project
run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)

# 3. Run comprehensive test suite
# Basic commands
run_terminal_cmd(command="cd p3_handout && echo -e \"help\nlist\nquit\" | ./hiy", is_background=false)

# Task creation and execution
run_terminal_cmd(command="cd p3_handout && echo -e \"ls\ncat fox.txt\nstart 1\nlist\nquit\" | ./hiy", is_background=false)

# Background execution
run_terminal_cmd(command="cd p3_handout && echo -e \"slow_cooker 5\nstartbg 1\nlist\nquit\" | ./hiy", is_background=false)

# File redirection
run_terminal_cmd(command="cd p3_handout && echo -e \"cat\ngrep the\nstart 1 > output.txt\nstart 2 < fox.txt\nlist\nquit\" | ./hiy", is_background=false)

# Pipe commands
run_terminal_cmd(command="cd p3_handout && echo -e \"cat fox.txt\ngrep the\npipe 1 2\nlist\nquit\" | ./hiy", is_background=false)
```

### Verification Process

The Verification Process should validate HIY shell functionality:

```
# 1. Read HIY shell guidance
read_file("1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md", should_read_entire_file=true)

# 2. Run verification tests
run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)

# 3. Verify core functionality
run_terminal_cmd(command="cd p3_handout && echo -e \"help\nlist\nls\nstart 1\nlist\nquit\" | ./hiy", is_background=false)

# 4. Document verification results
edit_file("1000xcycles/p3-master-cycle/operational_feedback/verification_report.md", "Update verification report", "...")
```

## Handling Dynamic Input Tests

For tests requiring dynamic input (e.g., tests with `slow_cooker`, interactive signals), provide clear guidance:

```
# For basic dynamic tests, use sleep and echo sequence
run_terminal_cmd(command="cd p3_handout && (echo \"slow_cooker 5\"; sleep 1; echo \"startbg 1\"; sleep 1; echo \"list\"; sleep 1; echo \"quit\") | ./hiy", is_background=false)

# For more complex tests, create a temporary script
run_terminal_cmd(command="cd p3_handout && echo -e '#!/bin/bash\necho \"slow_cooker 10\"\nsleep 2\necho \"startbg 1\"\nsleep 1\necho \"list\"\nsleep 5\necho \"kill 1\"\necho \"list\"\necho \"quit\"' > test.sh && chmod +x test.sh && ./test.sh | ./hiy && rm test.sh", is_background=false)
```

Document clearly which tests require manual interaction and cannot be automated.

## Error Handling

All HIY shell integration should include robust error handling:

1. **Compilation Errors**:
   * If compilation fails, check the error messages
   * Verify changes to hiy.c
   * Ensure all syntax is correct

2. **Runtime Errors**:
   * If HIY shell crashes or behaves unexpectedly, document the exact behavior
   * Compare against expected output from guidance documents
   * Make targeted fixes to address specific issues

3. **Terminal Command Failures**:
   * If terminal commands fail to execute, check basic environment setup
   * Verify paths are correct
   * Ensure required files exist
   * Try simplifying the command for debugging

## Integration Benefits

This standardized HIY shell integration approach provides:

1. **Consistency**: All processes interact with the HIY shell in the same way
2. **Reliability**: Standard patterns and error handling ensure reliable testing
3. **Efficiency**: Focused testing workflows prevent wasted effort
4. **Clarity**: Clear documentation of expected behavior and test patterns
5. **Traceability**: Easy to trace issues back to specific tests or commands

By following this integration approach, all p3-master-cycle processes will be able to effectively test and interact with the HIY shell, ensuring proper implementation of hiy.c. 