# Simplified Process Architecture for p3-master-cycle

## Core Design Principles

1. **Minimal Tool Calls**: Limit the number of tool calls to prevent context window overflow
2. **No Chunking**: Eliminate all chunking operations that lead to hallucinations
3. **Direct Documentation Access**: Use direct references to guidance files instead of trying to load full documentation
4. **Testing-First Approach**: Implement HIY shell testing before making changes to hiy.c
5. **Clear Process Flow**: Maintain a clear, linear progression through the cycle
6. **Error Handling**: Include robust error handling without excessive complexity
7. **Proper HIY Shell Integration**: Ensure all processes can properly interact with the HIY shell

## Standard Process Structure

Each process file will follow this streamlined structure:

```
# Process: [Name]

## Goal: [Clear, concise goal statement]

## Steps:

1. **Read Context**:
   * Read only essential context files (current_cycle.md, user_request.md, etc.)
   * NO chunking of large documentation files
   
2. **Process-Specific Steps**:
   * Clear, focused steps with minimal tool calls
   * Error handling at step level
   * Every step serves a clear purpose

3. **Update Status**:
   * Update operational feedback files
   * Signal completion or next steps

## Project Constraints:

1. **Only edit p3_handout/src/hiy.c**
2. **No comments during implementation**
3. **No new files outside allowed areas**

## Error Handling:

* Clear, focused error handling without excessive complexity
* Fall back to simple approaches when issues arise
```

## Core Process Flow

The p3-master-cycle will maintain the current 9-process structure but with simplified content:

1. **Initialization**:
   * Setup cycle
   * Read user request
   * Establish boundary enforcement
   
2. **Requirement Analysis**:
   * Analyze user request
   * Identify required changes
   * Reference HIY shell guides
   
3. **Planning**:
   * Create simple implementation plan
   * Focus on minimal, effective planning
   
4. **Implementation**:
   * Reference HIY shell guidance directly
   * Run tests BEFORE making changes
   * Make targeted changes to hiy.c
   * Re-test changes immediately
   
5. **Verification**:
   * Test all implemented changes
   * Ensure proper functionality
   
6. **Documentation**:
   * Minimal documentation approach
   * Focus on what was changed and why
   
7. **Completion**:
   * Update status
   * Verify all tasks completed
   
8. **Testing**:
   * Comprehensive HIY shell testing
   * Use the HIY shell guidance directly
   * Handle dynamic input tests properly
   
9. **Notification Handling**:
   * Process and resolve notifications
   * Update notification status

## HIY Shell Integration

HIY shell interaction will be standardized across all processes:

1. **Documentation Reference**:
   * Direct calls to HIY shell guidance documents:
     ```
     read_file("1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md", should_read_entire_file=true)
     read_file("1000xcycles/p3-master-cycle/operational_feedback/additional_hiy_tests.md", should_read_entire_file=true)
     read_file("1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md", should_read_entire_file=true)
     ```

2. **Terminal Execution**:
   * Standard terminal command pattern:
     ```
     # Compilation
     run_terminal_cmd(command="cd p3_handout && make clean && make", is_background=false)
     
     # HIY Shell Basic Testing (non-interactive)
     run_terminal_cmd(command="cd p3_handout && echo -e \"help\nquit\" | ./hiy", is_background=false)
     
     # HIY Shell Interactive Testing
     run_terminal_cmd(command="cd p3_handout && ./hiy", is_background=false)
     ```

3. **Testing Approach**:
   * Read test case from guidance
   * Execute test command
   * Verify expected output
   * Return to implementation if issues found

## Tool Call Optimization

Tool calls will be optimized to prevent context overflow:

1. **Documentation Reading**:
   * NO chunking of large files
   * Only read guidance documents directly
   * Focus on specific test cases and examples
   
2. **Code Editing**:
   * Read hiy.c once at the beginning of implementation
   * Make targeted edits based on test results
   * Re-test after each significant change
   
3. **Terminal Commands**:
   * Group related terminal commands together
   * Use appropriate error handling for terminal commands
   * Verify terminal command output carefully

## Boundary Enforcement

Boundary enforcement will be standardized across all processes:

1. **File Editing**:
   * Only edit p3_handout/src/hiy.c
   * Include boundary check before every edit operation
   
2. **Documentation**:
   * No modifications to project documentation
   * Read-only access to all guidance documents
   
3. **Error Handling**:
   * Clear error messages
   * Fallback approaches for common issues
   * Recovery strategies for failures

## Implementation Benefits

This simplified architecture provides several key benefits:

1. **Prevents Hallucinations**: By eliminating chunking and minimizing tool calls
2. **Improves Efficiency**: Through streamlined processes and clear structure
3. **Ensures Consistency**: With standardized HIY shell integration and error handling
4. **Maintains Focus**: On the core project goal of implementing hiy.c correctly
5. **Supports Testing**: With proper HIY shell integration and testing-first approach
6. **Robust Error Handling**: Without excessive complexity
7. **Clear Process Flow**: With logical progression through the cycle 