# USER REQUEST File
# This file is exclusively for storing USER REQUEST content to be read and processed by 1000xdev.
# Notes and personal content should be kept in notes.md.

## USER REQUEST SECTION

# --- OPTION SELECTION ---
# Select ONE option by removing the comment marker (#) from your selection:
OPTION 1: Resolve errors in p3-master-cycle notifications (autonomous mode)
# OPTION 2: Resolve errors in system-cycle-manager system_errors (autonomous mode)
# OPTION 3: New USER_DIRECTED request (requires filling all template fields below)
# OPTION 4: AUTONOMOUS mode (process potential enhancements automatically)

# --- OPERATION MODE ---
# Note: For options 1, 2, and 4, AUTONOMOUS_MODE will be used automatically.
# For option 3, remove the comment marker from your selection:
AUTONOMOUS_MODE
# USER_DIRECTED_MODE

# --- REQUEST DETAILS (Only needed for OPTION 3) ---
# Directive: [Enhancement|Fix|Refactor|Analysis]
# Target Cycle: [domain/cycle-name]
# Enhancement Name: [Brief descriptive name]
# Priority: [High|Medium|Low]

# Enhancement Details
[Provide a clear description of what needs to be done. Be specific about requirements.]

## Objective

**p3-master-cycle is CURRENTLY NOT USABLE**

There are many hallucinations that occur.

What you need to do to is replace the explicit chunking tool calls to the Master Project descriptions and completely change ALL of the processes. The processes are NOT FUNCTIONAL and almost every one results in a hallucination.

You need to DRASTICALLY simplify the tool calls to just make tool calls to guidelines so that during p3-master-cycle you know just enough to make changes AND run the terminal commands to execute tests within the HIY shell. HIY shell usage and instructions below (must be used in explicit tool calling within the processes)
1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md
1000xcycles/p3-master-cycle/operational_feedback/additional_hiy_tests.md
1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/all-examples-runs.md
1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md



**These files MUST be used throughout the cycles as explicit tool calls so you know how to use the HIY shell**

This process needs to be fast, because the project is almost due. There can only be 1 to 2 implementation phases. You need to go FAST.

As you create the guidelines, make tool calls to:
1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md 
1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md

For context on HIY shell testing, read:
1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md
1000xcycles/p3-master-cycle/operational_feedback/additional_hiy_tests.md
1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/all-examples-runs.md
1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md


Assume the processes are terrible and start over. I'm serious, start over. Less is more. I will attach an imagge of the latest planning process. While in p3-master-cycle, you assumed that hiy.c was not even implemented yet and we need to create the data structures again? In step 2, you need to actually read the USER REQUEST file so I can tell you the errors you need to resolve for the cycle. Throughout the cycle you should also autonomously run terminal commands based on the hiy shell guidelines AND the 

Again, I repeat, the current processes in p3-master-cycle are UNUSABLE. I am just chatting with you regularly in another thread for now to make changes to hiy.c. START FROM SCRATCH. There should be no chunking tool calls, only tool calls to guidance files and clearly listed steps to first run tests (running tests should be in planning and research to find errors) and then making changes, then re-verifying in step 5, then refining in step 6, then running finals 

IF POSSIBLE reduce the steps as well. 

You do NOT need to reference the guidelines when making changes to the processes. Start from scratch. Limit the number of tool calls so that the context window does not fill up before the process is even done.

You MUST utilize all four files based on HIY shell guidelines and usage throughout this entire cycle to ENSURE that the next couple cycles for p3-master-cycle autonomous iterate on CURRENT tests in the HIY shell and CORRECT changes to hiy.c. Include guidelines to try to keep iterating until the HIY shell output matches the example runs (some of the runs require dynamic input, in which those you can do your best to mimic). Some tests require dynamic input (tests with slow_cooker etc.), where you will need to execute the sequential terminal command as the . These dynamic input tests will be marked with `## DYNAMIC INPUT`.
1000xcycles/p3-master-cycle/operational_feedback/hiy_shell_commands_guide.md
1000xcycles/p3-master-cycle/operational_feedback/additional_hiy_tests.md
1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/all-examples-runs.md
1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md

These four files may ALSO be used for explicit tool calling during the processes.

PROCESSES YOU WILL EDIT ARE ALL HERE: 1000xcycles/p3-master-cycle/processes
COMMANDS YOU WILL EDIT ARE ALL HERE: 1000xcycles/p3-master-cycle/commands


## Deliverable

The final deliverable is the file:
`1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md`

This file MUST be populated with accurate command sequences based on the project documentation and verified through actual execution in the HIY shell.

## Process

1.  **Source Material Review (Mandatory)**:
    *   Thoroughly re-read the **entire** project documentation located in:
        *   `1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-1-20.md`
        *   `1000xbrain/knowledge-base/p3_strict_instructions/master-project-documentation/mpd-21-35.md`
    *   Pay close attention to all sections labeled "Example Run" or containing `HIY$` prompts, as these provide the core test cases.
    *   Review `1000xbrain/guidelines/cs367-p3/test-cases.md` for a structured overview, but prioritize examples directly from the MPDs.

2.  **Cheatsheet Structure**:
    *   Populate `1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md` with the following sections:

        *   **Setup and Teardown**:
            *   Commands to navigate to the `p3_handout` directory (`cd p3_handout`).
            *   Commands to clean the build (`make clean`).
            *   Commands to compile the project (`make`).
            *   Command to start the HIY shell (`./hiy`).
            *   Command to exit the HIY shell (`quit`).
            *   **Crucial**: Ensure all subsequent HIY commands assume they are run *inside* the `./hiy` shell started from the `p3_handout` directory.

        *   **Core Functionality Tests (Directly from MPD Examples)**:
            *   Extract **at least 4 distinct, non-trivial command sequences** directly from the "Example Run" sections in the MPDs (mpd-1-20.md and mpd-21-35.md).
            *   Include sequences demonstrating:
                *   Basic commands (`help`, `list`, task creation).
                *   Process execution (`start`, `startbg`).
                *   Process control (`kill`, `suspend`, `fg`, `bg`).
                *   Piping (`pipe`).
                *   Redirection (`<`, `>`).
                *   Keyboard signals (Ctrl+C, Ctrl+Z, Ctrl+\\ - describe the action, as the keys cannot be scripted directly).
            *   Present each sequence clearly, showing the input commands.

        *   **Edge Case Tests (Derived or from MPD)**:
            *   Develop and include **at least 8 additional test sequences** covering potential edge cases or less common scenarios described in the MPDs. Examples include:
                *   Deleting non-existent tasks.
                *   Deleting busy tasks.
                *   Starting/controlling non-existent tasks.
                *   Piping identical task numbers.
                *   Attempting invalid state transitions (e.g., `bg` on a foreground task).
                *   Commands that fail execution (e.g., `delicious pancakes`).
                *   Testing exit codes (`my_echo`).
                *   Complex signal interactions (`my_pause`, `slow_cooker`).

3.  **Verification (Mandatory)**:
    *   For **every** command sequence added to the cheatsheet:
        *   Execute the sequence step-by-step within the actual `./hiy` shell (after `cd p3_handout; make`).
        *   Verify that the observed behavior and output **exactly** match the expectations derived from the project documentation (MPDs).
        *   **Crucial**: Correct any discrepancies found in the cheatsheet commands to ensure accuracy. The goal is a script that *works*.

4.  **Final Output**:
    *   Ensure `1000xbrain/guidelines/cs367-p3/hiy-shell-commands.md` is well-formatted (using markdown) and contains only the verified, accurate command sequences.

## Constraints Reminder

*   Only `hiy.c` can be modified if issues arise during testing (though none are expected for this task).
*   Adhere strictly to the HIY command syntax documented in the MPDs.
*   Run all terminal commands autonomously.

# Focus Areas (Optional)
[Specific files or components that should receive attention]

# Autonomous Settings (Only used in AUTONOMOUS_MODE)
# Primary Focus: [p3-master-cycle|system-cycle-manager|both]
# Self-Enhancement: [Enabled|Disabled]
# Enhancement Selection: [Highest Priority|Balance Priority and Complexity|User Suggestion]

## END USER REQUEST SECTION 