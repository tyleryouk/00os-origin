# Consolidated Feedback Template

This template defines the standardized structure for the five core operational feedback files that will be used across all cycles.

## 1. Current Cycle Template (`current_cycle.md`)

```markdown
# Current Cycle Status

**Cycle ID**: [CYCLE-ID]
**Status**: [CURRENT-STATUS]
**Operation Mode**: [USER_DIRECTED_MODE/AUTONOMOUS_MODE]
**Selected Option**: [OPTION_DESCRIPTION]
**Current Phase**: [CURRENT-PHASE]

## Progress Summary

**Implementation Status**: [PHASE-STATUS]
**Last Updated**: [TIMESTAMP]
**Overall Progress**: [PERCENTAGE]%

## Recent Logs

**[TIMESTAMP] [PHASE]**: [LOG-ENTRY]
**[TIMESTAMP] [PHASE]**: [LOG-ENTRY]
...

## Document References

| Document | Location |
|----------|----------|
| User Request | [PATH] |
| Change Request | [PATH] |
| Implementation Plan | [PATH] |
| Implementation Progress | [PATH] |
| Implementation Iteration | [PATH] |
| Completion Summary | [PATH] |

## Phase Results

### Phase 1: [PHASE-NAME]
* **Status**: [COMPLETE/IN PROGRESS/UPCOMING]
* **Key Deliverables**:
  - [DELIVERABLE-1]
  - [DELIVERABLE-2]
  ...

### Phase 2: [PHASE-NAME]
* **Status**: [COMPLETE/IN PROGRESS/UPCOMING]
* **Key Deliverables**:
  - [DELIVERABLE-1]
  - [DELIVERABLE-2]
  ...

## Next Step

[NEXT-STEP-INSTRUCTION]

## Option Availability

[AVAILABLE-OPTIONS]

**Recommended Priority**: [PRIORITY-RECOMMENDATION]
```

## 2. Change Request Template (`change_request.md`)

```markdown
# Change Request

**Cycle ID**: [CYCLE-ID]
**Request Date**: [TIMESTAMP]
**Requested By**: [USER-ID]
**Request Type**: [ENHANCEMENT/BUG-FIX/REFACTOR]
**Priority**: [HIGH/MEDIUM/LOW]
**Status**: [PENDING/APPROVED/IN PROGRESS/COMPLETED/REJECTED]

## Request Description

[DETAILED-DESCRIPTION]

## Business Justification

[JUSTIFICATION]

## Requirements

1. [REQUIREMENT-1]
2. [REQUIREMENT-2]
...

## Constraints

* [CONSTRAINT-1]
* [CONSTRAINT-2]
...

## Success Criteria

* [CRITERION-1]
* [CRITERION-2]
...

## Implementation Notes

[IMPLEMENTATION-NOTES]

## Change History

**[TIMESTAMP]**: [CHANGE-DESCRIPTION]
**[TIMESTAMP]**: [CHANGE-DESCRIPTION]
...

## Approval Information

**Approved By**: [APPROVER]
**Approval Date**: [TIMESTAMP]
**Approval Notes**: [NOTES]
```

## 3. Implementation Plan Template (`implementation_plan.md`)

```markdown
# Implementation Plan

**Cycle ID**: [CYCLE-ID]
**Plan Created**: [TIMESTAMP]
**Implementation Approach**: [APPROACH]

## Overview

[OVERVIEW-PARAGRAPH]

## Analysis Summary

[ANALYSIS-SUMMARY]

## Phases

### Phase 1: [PHASE-NAME]

**Objective**: [OBJECTIVE]
**Tasks**:

1. [TASK-1]
   * **Files**: [FILES]
   * **Changes**: [CHANGES]
   * **Dependencies**: [DEPENDENCIES]

2. [TASK-2]
   * **Files**: [FILES]
   * **Changes**: [CHANGES]
   * **Dependencies**: [DEPENDENCIES]
...

### Phase 2: [PHASE-NAME]
...

## Implementation Strategy

**Iterative Approach**:

* **Iteration 1**: [ITERATION-DESCRIPTION]
* **Iteration 2**: [ITERATION-DESCRIPTION]
...

## Verification Approach

1. [VERIFICATION-STEP-1]
2. [VERIFICATION-STEP-2]
...

## Risk Assessment

**Potential Issues**:

* **[RISK-1]**: [DESCRIPTION]
  * **Mitigation**: [MITIGATION-STRATEGY]

* **[RISK-2]**: [DESCRIPTION]
  * **Mitigation**: [MITIGATION-STRATEGY]
...

## Next Steps

1. [NEXT-STEP-1]
2. [NEXT-STEP-2]
...

## Special Notes

* [NOTE-1]
* [NOTE-2]
...
```

## 4. Implementation Progress Template (`implementation_progress.md`)

```markdown
# Implementation Progress

**Cycle ID**: [CYCLE-ID]
**Last Updated**: [TIMESTAMP]
**Overall Progress**: [PERCENTAGE]%

## Current Iteration

* **Iteration Number**: [NUMBER]
* **Status**: [STATUS]
* **Tasks Completed**: [COMPLETED] / [TOTAL]
* **Tasks Partially Completed**: [PARTIAL] / [TOTAL]
* **Issues Encountered**: [COUNT]

## Task Status Summary

* **Not Started**: [COUNT]
* **In Progress**: [COUNT]
* **Completed**: [COUNT]
* **Blocked**: [COUNT]
* **Needs Revision**: [COUNT]
* **Skipped**: [COUNT]

## Iteration History

1. **Iteration [NUMBER]**:
   * **Started**: [TIMESTAMP]
   * **Completed**: [TIMESTAMP]
   * **Tasks Completed**: [COMPLETED] / [TOTAL]
   * **Key Accomplishments**: 
     - [ACCOMPLISHMENT-1]
     - [ACCOMPLISHMENT-2]
     ...

## Completed Tasks

### Task: [TASK-NAME]
* **Priority**: [PRIORITY]
* **Status**: Completed
* **Outcome**: [OUTCOME]
* **Completed**: [TIMESTAMP]
* **Key Findings**: [OPTIONAL]
  - [FINDING-1]
  - [FINDING-2]
  ...

## In-Progress/Current Tasks

### Task: [TASK-NAME]
* **Priority**: [PRIORITY]
* **Estimated Effort**: [EFFORT]
* **Dependencies**: [DEPENDENCIES]
* **Implementation Approach**: [APPROACH]
* **Status**: [STATUS]
* **Notes**: [NOTES]

## Upcoming Iterations

### Iteration [NUMBER]: [ITERATION-NAME]
* **Planned Start**: [TIMESTAMP]
* **Status**: [STATUS]
* **Tasks**: 
  - [TASK-1]
  - [TASK-2]
  ...

## Implementation Risks and Mitigations

* **Risk**: [RISK-DESCRIPTION]
  * **Mitigation**: [MITIGATION-STRATEGY]

## Notes

* [NOTE-1]
* [NOTE-2]
...
```

## 5. Completion Summary Template (`completion_summary.md`)

```markdown
# Completion Summary

**Cycle ID**: [CYCLE-ID]
**Completion Date**: [TIMESTAMP]
**Cycle Duration**: [DURATION]
**Final Status**: [STATUS]

## Executive Summary

[EXECUTIVE-SUMMARY]

## Goals and Objectives

**Original Objectives**:
1. [OBJECTIVE-1]
2. [OBJECTIVE-2]
...

**Achievement Status**:
* [OBJECTIVE-1]: [ACHIEVED/PARTIALLY ACHIEVED/NOT ACHIEVED]
* [OBJECTIVE-2]: [ACHIEVED/PARTIALLY ACHIEVED/NOT ACHIEVED]
...

## Key Deliverables

1. **[DELIVERABLE-1]**
   * **Description**: [DESCRIPTION]
   * **Location**: [PATH]
   * **Status**: [STATUS]

2. **[DELIVERABLE-2]**
   * **Description**: [DESCRIPTION]
   * **Location**: [PATH]
   * **Status**: [STATUS]
...

## Performance Metrics

* **Initial Baseline**: [BASELINE]
* **Final Measurement**: [MEASUREMENT]
* **Improvement**: [PERCENTAGE]%

## Issues and Resolutions

### Issue: [ISSUE-1]
* **Description**: [DESCRIPTION]
* **Impact**: [IMPACT]
* **Resolution**: [RESOLUTION]

### Issue: [ISSUE-2]
* **Description**: [DESCRIPTION]
* **Impact**: [IMPACT]
* **Resolution**: [RESOLUTION]
...

## Lessons Learned

* [LESSON-1]
* [LESSON-2]
...

## Future Recommendations

1. [RECOMMENDATION-1]
2. [RECOMMENDATION-2]
...

## Final Validation

**Validation Method**: [METHOD]
**Validator**: [VALIDATOR]
**Validation Date**: [TIMESTAMP]
**Validation Result**: [RESULT]

## Appendices

* **Appendix A**: [APPENDIX-DESCRIPTION]
* **Appendix B**: [APPENDIX-DESCRIPTION]
...