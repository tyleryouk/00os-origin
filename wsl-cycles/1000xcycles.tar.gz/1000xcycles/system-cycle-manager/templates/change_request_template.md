# Change Request

**Cycle ID**: [CYCLE-ID-FORMAT: XXX-YYYY-MM-DD-NNN]
**Request Date**: [YYYY-MM-DD]
**Requestor**: [USER/SYSTEM]
**Priority**: [HIGH/MEDIUM/LOW]
**Type**: [ENHANCEMENT/BUG FIX/FEATURE/OPTIMIZATION]
**Status**: [APPROVED/PENDING/IN PROGRESS/COMPLETED]

## Request Summary

[Concise 2-3 sentence summary of the change request, including what is being changed and why]

## Detailed Description

[Comprehensive description of the requested change, including:
- Background context
- Current system state
- Proposed changes
- Expected benefits
- Any known constraints or limitations]

## Requirements

### Functional Requirements

1. [Specific, measurable requirement]
2. [Specific, measurable requirement]
3. [Specific, measurable requirement]
   * [Sub-requirement if needed]
   * [Sub-requirement if needed]

### Non-Functional Requirements

1. [Performance requirement]
2. [Security requirement]
3. [Maintainability requirement]
4. [Compatibility requirement]

### Constraints

* [Technical constraint]
* [Process constraint]
* [Resource constraint]
* [Timeline constraint]

## Success Criteria

* [Criterion 1: How will success be measured?]
* [Criterion 2: How will success be measured?]
* [Criterion 3: How will success be measured?]

## Implementation Considerations

* [Key consideration 1]
* [Key consideration 2]
* [Key consideration 3]

## Affected Components

| Component | Impact Level | Description of Change |
|-----------|--------------|------------------------|
| [Component Name] | [HIGH/MEDIUM/LOW] | [Brief description of how this component will be affected] |
| [Component Name] | [HIGH/MEDIUM/LOW] | [Brief description of how this component will be affected] |

## Dependencies

* [Dependency 1: What must be in place before this change can be implemented?]
* [Dependency 2: What must be in place before this change can be implemented?]

## Timeline

* **Expected Start Date**: [YYYY-MM-DD]
* **Expected Completion Date**: [YYYY-MM-DD]
* **Milestones**:
  - [Milestone 1]: [YYYY-MM-DD]
  - [Milestone 2]: [YYYY-MM-DD]
  - [Milestone 3]: [YYYY-MM-DD]

## Approval

* **Approved By**: [Name/Role]
* **Approval Date**: [YYYY-MM-DD]
* **Notes**: [Any notes related to approval]

## Attachments

* [Reference Document 1]: [Path or Link]
* [Reference Document 2]: [Path or Link] 