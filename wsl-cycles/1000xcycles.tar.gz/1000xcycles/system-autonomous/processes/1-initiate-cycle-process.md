# Process: Initiate Autonomous Enhancement Cycle

# Defines the process for initiating a new enhancement cycle

## Goal: Create a new operational state, initialize logs, and prepare for research phase.

## Steps:

1.  **Read Current Progress File**:
    *   Use `read_file` to read `1000xplans/system/implementation-progress.md`.
    *   Check if a cycle is already in progress (look for "Current Cycle Status" section).
    *   **(Error Handling)**: If a cycle is in progress and not completed, log warning but continue.

2.  **Create/Update Cycle Log**:
    *   Create or append to `1000xbrain/system/autonomous/operational_feedback/cycle_log.md`.
    *   Add entry with timestamp, cycle number, and "INITIATED" status.
    *   Use `edit_file` to update the cycle log.

3.  **Initialize USER REQUEST SECTION**:
    *   Use `edit_file` to completely overwrite `1000xplans/system/user_request.md`:
        ```markdown
        # USER REQUEST File
        # This file is exclusively for storing USER REQUEST content to be read and processed by 1000xdev.
        # Notes and personal content should be kept in notes.md.

        ## USER REQUEST SECTION
        
        # --- TEMPLATE START ---
        # Instructions:
        # 1. Replace bracketed placeholders with your request details.
        # 2. All directive fields are required - they help automate processing.
        # 3. Run `1000xscripts/system/list-cycles.ps1` in terminal to see all available cycles.

        # Directive: [Enhancement|Fix|Refactor|Analysis]
        # Target Cycle: [domain/cycle-name]
        # Enhancement Name: [Brief descriptive name]
        # Priority: [High|Medium|Low]

        # Enhancement Details
        [Provide a clear description of what needs to be done. Be specific about requirements.]

        # Focus Areas (Optional)
        [Specific files or components that should receive attention]

        # --- DIRECTIVE REFERENCE ---
        # Enhancement: Add new functionality or improve existing features
        # Fix: Correct problems or issues in existing functionality
        # Refactor: Restructure code without changing functionality
        # Analysis: Evaluate component(s) without making changes
        # --- TEMPLATE END ---

        ## END USER REQUEST SECTION
        ```
    *   **IMPORTANT**: Do NOT preserve previous requests in user_request.md - it should be completely overwritten
    *   **(Error Handling)**: If template creation fails, provide clear error message.

4.  **Initialize Operational Feedback**:
    *   Create new directory for this cycle's feedback: `1000xbrain/system/autonomous/operational_feedback/cycle_[number]/`.
    *   Create empty files for different phases:
        *   `research_findings.md` - Will contain research results
        *   `implementation_log.md` - Will track implementation changes
        *   `verification_results.md` - Will contain verification outcomes
        *   `refinement_log.md` - Will track any refinements needed

5.  **Update Progress Tracker**:
    *   Use `edit_file` to update `1000xplans/system/implementation-progress.md`.
    *   Mark "Cycle Initiated" as completed.
    *   Add timestamp to "Last Updated" field.
    *   Set status to "Research Phase Pending".

6.  **Prepare System State**:
    *   Create `1000xbrain/system/autonomous/operational_feedback/current_state.md` with:
        *   Current cycle number and timestamp
        *   Current phase: "Research"
        *   Status: "Pending"
        *   Operation Mode: Based on USER REQUEST SECTION (default to "AUTONOMOUS" if not specified)
        *   Next command to execute: `run command:system/autonomous/2`

7.  **Check Cycle System Guidelines**:
    *   Verify alignment with `1000xbrain/system/cycle-manager/knowledge/cycle-system-guidelines.md`.
    *   Ensure this process follows the guideline to completely overwrite user_request.md.

8.  **Signal Completion and Next Steps**:
    *   Provide summary of initialization actions taken.
    *   Explicitly mention next step: `run command:system/autonomous/2` for research phase.

## Special Considerations

1. **User Request Handling**:
   * ALWAYS completely overwrite user_request.md rather than preserving previous requests
   * This keeps the user_request.md file concise and focused on the current request only
   * Previous requests should be archived elsewhere if needed

2. **Sequential Cycle Pattern**:
   * Follow the standard sequential step pattern (1, 2, 3, etc.)
   * Ensure clear state transitions between steps
   * Maintain proper operational feedback structure

3. **Autonomous Operation**:
   * The autonomous cycle should be able to operate with minimal user input
   * Default to AUTONOMOUS mode when appropriate 